//
//  ParthenoKit.h
//  ParthenoKit
//
//  Created by Ignazio Finizio on 24/11/20.
//

#import <Foundation/Foundation.h>

//! Project version number for ParthenoKit.
FOUNDATION_EXPORT double ParthenoKitVersionNumber;

//! Project version string for ParthenoKit.
FOUNDATION_EXPORT const unsigned char ParthenoKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ParthenoKit/PublicHeader.h>


