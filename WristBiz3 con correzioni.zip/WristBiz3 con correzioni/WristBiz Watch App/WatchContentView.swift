//
//  ContentView.swift
//  conn4 Watch App
//
//  Created by Ciro Pazzi on 11/02/23.
//

import WatchConnectivity
import SwiftUI

class WatchViewModel: NSObject, ObservableObject, WCSessionDelegate {
    @Published var receivedMessage: Int = 0
    @Published var meetingCode: String = ""
    @Published var goOut: String = "false"
    private let session = WCSession.default
    
    func sendMessageToiPhone(_ message: String) {
        session.sendMessage(["message": message], replyHandler: nil) { (error) in
            print(error.localizedDescription)
        }
    }
    
    func sendGoOutToiPhone(_ message: String) { //§§§§
        session.sendMessage(["goOut": message], replyHandler: nil) { (error) in
            print(error.localizedDescription)
        }
    }
    
    override init() {
        super.init()
        
        if WCSession.isSupported() {
            session.delegate = self
            session.activate()
        }
    }
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        // Implement this method to handle the activation state of a session.
    }
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        if let message = message["message"] as? Int {
            receivedMessage = message
        }
    }
}

struct WatchContentView: View {
    @StateObject var viewModel = WatchViewModel()
    @State var Count: Int = 1
    @State var isOut: Bool = false
    var body: some View {
        NavigationView{
            ScrollView{
                VStack(alignment: .center) {
                    
                    Text("Join a meeting")
                        .foregroundColor(.white)
                        .font(.custom("San Francisco", size: 23))
                        Spacer(minLength: 10)
                    NavigationLink(destination: SceltaInviati(viewModel: viewModel, isPresented: $isOut, meetC: String("")), label: {
                        Image(systemName: "person.line.dotted.person")
                            .tint(.black)
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding(20)
                            .background(.blue, in: Circle())
                        
                    }).tint(.black)
                        .padding(15)
                    
                }.padding(20)
                
                
            }
        }
    }
}
struct WatchContentView_Previews: PreviewProvider {
    static var previews: some View {
        WatchContentView()
    }
}
