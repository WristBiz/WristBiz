//
//  SceltaInviati.swift
//  WristBiz Watch App
//
//  Created by Ciro Pazzi on 10/02/23.
//

import SwiftUI
import WatchConnectivity

struct SceltaInviati: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode> //§§§§
    
    @ObservedObject var viewModel: WatchViewModel
    @State private var isPressed = false
    @Binding var isPresented: Bool
    @State var meetC: String
    var body: some View {
        NavigationView{
            ScrollView{
                VStack() {
                    Text("\(viewModel.meetingCode)")
                        .font(.footnote)
                        .bold()
                        .padding()
                    HStack(spacing: 1) {
                        ForEach(1...3, id: \.self) { row in
                            VStack(spacing: 1) {
                                ForEach(1...3, id: \.self) { column in
//                                    GeometryReader { geometry in
                                        Button("\((column - 1) * 3 + row)") {
                                            viewModel.meetingCode.append("\((column - 1) * 3 + row)")
                                        }
//                                        .frame(width: geometry.size.width / 4, height: geometry.size.height / 2)
//                                    }
                                }
                            }
                        }
                        
                    }
                    HStack{
//                        GeometryReader { geometry in
                            Button(action: {
                                viewModel.sendMessageToiPhone(viewModel.meetingCode)
                                self.meetC = viewModel.meetingCode
                                self.isPressed = true
                                viewModel.goOut = "false" //§§§§
                                viewModel.sendGoOutToiPhone(viewModel.goOut)//§§§§
                            }, label:
                                    {
                                Image(systemName: "checkmark")
                            })
//                            .frame(width: geometry.size.width / 4, height: geometry.size.height / 2)
                            .background(Color(hue: 0.363, saturation: 0.956, brightness: 0.56)).cornerRadius(10)
                                .sheet( isPresented: $isPressed, onDismiss: {
                                    print("onDismiss....")
                                    viewModel.goOut = "true"
                                    viewModel.sendGoOutToiPhone(viewModel.goOut) //§§§§
                                    viewModel.meetingCode.removeAll()
                                } ,content: {
                                    InRiunione(meetingCode: $meetC,viewModel: viewModel, isPressed: $isPressed)
                                })
                            
                            Button(action: {
                                viewModel.meetingCode.append("0")
                            }, label: {
                                Text("0")
                            })
//                            .frame(width: geometry.size.width / 4, height: geometry.size.height / 2)
                            .cornerRadius(10)
                            Button(action: {
                                viewModel.meetingCode = String(viewModel.meetingCode.dropLast())
                            }, label: {
                                Image(systemName: "xmark")
                            })
//                            .frame(width: geometry.size.width / 4, height: geometry.size.height / 2)
                            .background(Color(hue: 0.001, saturation: 0.997, brightness: 0.93)).cornerRadius(10)
                        }
//                    }
                }.padding(20)
            }
        }
    }
}
//struct SceltaInviati_Previews: PreviewProvider {
//    static var previews: some View {
//        SceltaInviati(viewModel: WatchViewModel())
//    }
//}

struct InRiunione: View {
    @Binding var meetingCode: String
    @ObservedObject var viewModel : WatchViewModel
    @Binding var isPressed: Bool
    
    var body: some View {
        Text("You're in the meeting: \(meetingCode)")
            .font(.title3)
            .foregroundColor(.white)
        
//        NavigationLink(destination: WatchContentView()){
//            Text("esci")
//        }
        Button(action: {
            viewModel.goOut = "true"
            viewModel.sendMessageToiPhone(viewModel.goOut)
        }, label:
                {
            Text("Leave meeting")
        })

            .sheet(isPresented: $isPressed, content: {
                WatchContentView()
            })

        
    }
    
}

//struct InRiunione_Preview: PreviewProvider{
//var viewModel: WatchViewModel
//    static var previews: some View{
//        InRiunione(viewModel: WatchViewModel())
//    }
//}
