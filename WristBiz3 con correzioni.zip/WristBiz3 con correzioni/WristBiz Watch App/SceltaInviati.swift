//
//  SceltaInviati.swift
//  WristBiz Watch App
//
//  Created by Ciro Pazzi on 10/02/23.
//

import SwiftUI
import WatchConnectivity

struct SceltaInviati: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @ObservedObject var viewModel: WatchViewModel
    @State private var isPressed = false
    @Binding var isPresented: Bool
    @Binding var isEntering: Bool
    @State var meetC: String
    var body: some View {
        NavigationView{
            ScrollView{
                VStack{
                    Text(" ")
                    Text("\(viewModel.meetingCode)")
                        .font(.title3)
                        .bold()
                        .padding()
                    HStack(spacing: 3) {
                        ForEach(1...3, id: \.self) { column in
                            VStack(spacing: 3) {
                                ForEach(1...3, id: \.self) { row in
                                    Button("\((row - 1) * 3 + column)") {
                                        viewModel.meetingCode.append("\((row - 1) * 3 + column)")
                                    }.frame(width: 50, height: 40)
                                        .cornerRadius(10)
                                    
                                }
                            }
                        }
                        
                    }
                    VStack{
                        HStack(spacing: 3){
                            Button(action: {
                                viewModel.sendMessageToiPhone(viewModel.meetingCode)
                                self.meetC = viewModel.meetingCode
                                self.isPressed = true
                                viewModel.goOut = "false"
                                viewModel.sendGoOutToiPhone(viewModel.goOut)
                            }, label:
                                    {
                                Image(systemName: "checkmark")
                            }).frame(width: 50, height: 40)
                            
                                .background(Color(hue: 0.363, saturation: 0.956, brightness: 0.56)).cornerRadius(10)
                                .sheet( isPresented: $isPressed, onDismiss: {
                                    print("onDismiss....")
                                    viewModel.goOut = "true"
                                    viewModel.sendGoOutToiPhone(viewModel.goOut)
                                    viewModel.meetingCode.removeAll()
//                                    presentationMode.wrappedValue.dismiss()
                                },content: {
                                    InRiunione(meetingCode: $meetC,viewModel: viewModel, isPressed: $isPressed)
                                })
                            
                            Button(action: {
                                viewModel.meetingCode.append("0")
                            }, label: {
                                Text("0")
                            }).frame(width: 50, height: 40)
                            
                                .cornerRadius(10)
                            Button(action: {
                                viewModel.meetingCode = String(viewModel.meetingCode.dropLast())
                            }, label: {
                                Image(systemName: "xmark")
                            }).frame(width: 50, height: 40)
                            
                                .background(Color(hue: 0.001, saturation: 0.997, brightness: 0.93)).cornerRadius(10)
                        }
                        //                        NavigationLink(destination: {
                        //                            InRiunione(meetingCode: $meetC,viewModel: viewModel, isPressed: $isPressed)
                        //                        }, label: {
                        //                            Text("entra")
                        //                        })
                    }
                }
                
            }
        }
        
    }
}



struct InRiunione: View {
    @Binding var meetingCode: String
    @ObservedObject var viewModel : WatchViewModel
    @Binding var isPressed: Bool
    
    var body: some View {
        VStack{
            Text("You're in the meeting: \(meetingCode)")
                .font(.title3)
                .foregroundColor(.white)
        }
        //        NavigationLink(destination: WatchContentView()){
        //            Text("esci")
        //        }
        //        Button(action: {
        //            viewModel.goOut = "true"
        //            viewModel.sendMessageToiPhone(viewModel.goOut)
        //        }, label:
        //                {
        //            Text("Leave meeting")
        //        })
        
        //             Button(action: {
        //                print("onDismiss....")
        //                viewModel.goOut = "true"
        //                viewModel.sendGoOutToiPhone(viewModel.goOut)
        //                viewModel.meetingCode.removeAll()
        //                isPressed = true
        //            }, label: {
        //                Text("esci")
        //            })
        //
        
    }
    
}

