//
//  ContentView.swift
//  WristBiz Watch App
//
//  Created by Ciro Pazzi on 10/02/23.
//

//import SwiftUI
//
//struct ContentView: View {
//    var count: Int = 2
//    var body: some View {
//        NavigationView{
//            ScrollView{
//                ZStack{
//                    VStack{
//                        switch(count){
//                        case(1):
//                            NavigationLink(destination: SceltaInviati()) {
//                                Image("Biglietto1")
//                                    .resizable()
//                                    .aspectRatio(contentMode: .fill)
//                                    .font(.title)
//                                    .foregroundColor(.white)
//                                
//                            }
//                            .tint(.black)
//                        case(2):
//                            NavigationLink(destination: SceltaInviati()) {
//                                Image("Biglietto2")
//                                    .resizable()
//                                    .aspectRatio(contentMode: .fill)
//                                    .font(.title)
//                                    .foregroundColor(.white)
//                                
//                            }
//                            .tint(.black)
//                        case(3):
//                            NavigationLink(destination: SceltaInviati()) {
//                                Image("card3")
//                                    .resizable()
//                                    .aspectRatio(contentMode: .fill)
//                                    .font(.title)
//                                    .foregroundColor(.white)
//                                
//                            }
//                            .tint(.black)
//                        default:
//                            Text("Error")
//                        }
//                    }
//                }
//            }
//        }
//    }
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
