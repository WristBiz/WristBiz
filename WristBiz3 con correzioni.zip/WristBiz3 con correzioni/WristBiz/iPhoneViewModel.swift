
import WatchConnectivity
import SwiftUI

class iPhoneViewModel: NSObject, ObservableObject, WCSessionDelegate {
    @Published var receivedMessage: Int = 0
    @Published var meetingCode: String = ""
    @Published var goOut: String = "false"
    private let session = WCSession.default
    
    func sendMessageToWatch(_ message: Int) {
        session.sendMessage(["message": message], replyHandler: nil) { (error) in
            print(error.localizedDescription)
        }
    }
    
    override init() {
        super.init()
        
        if WCSession.isSupported() {
            session.delegate = self
            session.activate()
        }
    }
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        // Implementazione obbligatoria
    }
    
    func sessionDidBecomeInactive(_ session: WCSession) {
        // Implementazione opzionale
    }
    
    func sessionDidDeactivate(_ session: WCSession) {
        // Implementazione opzionale
    }
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        if let mess = message["message"] as? String {
            meetingCode = mess
        }
        
        if let goOutVal = message["goOut"] as? String { //§§§§
            goOut = goOutVal
        }
    }
}


