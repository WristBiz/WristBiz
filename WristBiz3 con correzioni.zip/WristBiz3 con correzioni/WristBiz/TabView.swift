//
//  TabView.swift
//  carte
//
//  Created by Assunta Pia Clarino on 16/02/23.
//

import Foundation
import SwiftUI
import PhotosUI
import ParthenoKit

struct MyTabView: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    @State var personalData = IstanzeBigliettoAziendale()
    @State private var selectedTab = 0
    @StateObject var viewModel = iPhoneViewModel()
    @AppStorage("bigliettiSalvati") var bigliettiSalvati : ArrayBiglietti = []
    @AppStorage("cards") var cards : ArrayBiglietti = []
    @State var bigliettoDefault : IstanzeBigliettoAziendale = IstanzeBigliettoAziendale()
//    @State private var bigliettiScartati : [IstanzeBigliettoAziendale] = []
    @AppStorage("BigliettiLetti") var BigliettiLetti : ArrayBiglietti = []
    @AppStorage("BigliettiScartati") var BigliettiScartati : ArrayBiglietti = []
    let timer = Timer.publish(every: 4, on: .main, in: .common).autoconnect()
    let timer1 = Timer.publish(every: 10, on: .main, in: .common).autoconnect()
    @State var p: ParthenoKit = ParthenoKit()
    @State var hoScritto: Bool = false
    @AppStorage("mioTag") var mioTag : StringToSave = ""
    @AppStorage("tagExsists") var tagExsists: BoolToSave = false
    
    var body: some View {
       
        TabView(selection: $selectedTab){
            NavigationStack {
                Wallet(cards: $cards, viewModel: viewModel, currentCard: IstanzeBigliettoAziendale(), bigliettoDefault: $bigliettoDefault)
            }
            

            
            .tabItem {
                Text("Mine")
                Image(systemName: "shared.with.you")
                    .padding()
            }

            .tag(0)
            
            Color.white
                .opacity(0.25)
                .edgesIgnoringSafeArea(.all)
                .overlay(
                    Wallet3( viewModel: viewModel, BigliettiLetti: $BigliettiLetti, bigliettiSalvati: $bigliettiSalvati,bigliettiScartati: $BigliettiScartati)
                )
                .tabItem {
                    Text("Received")
                    Image(systemName: "tray.and.arrow.down")
                        .padding()
                }
                .tag(1)
            
            Color.white
                .opacity(0.25)
                .edgesIgnoringSafeArea(.all)
                .overlay(
                    RicevutiSalvati(bigliettiSalvati: $bigliettiSalvati)
                )
                .tabItem {
                    Text("Stored")
                    Image(systemName: "folder.badge.person.crop")
                        .padding()
                }
                .tag(2)
            
            Color.white
                .opacity(0.25)
                .edgesIgnoringSafeArea(.all)
                .overlay(
                    Riunioni(viewModel: viewModel, mioTag: $mioTag)
                )
                .tabItem {
                    Text("Meetings")
                    Image(systemName: "list.number")
                        .padding()
                }
                .tag(3)
           
        }
        .accentColor(Color.white)
//        .toolbar(.visible, for: .tabBar)
//        .toolbarBackground(Color(red: 0.000, green: 0.013, blue: 0.422), for: .tabBar)
        
        .onReceive(timer) {
            _ in
            print("goOut: \(viewModel.goOut)")
            if(viewModel.meetingCode != "") && (viewModel.goOut == "false"){
                print("meeting code: \(viewModel.meetingCode)")
                print("...prima")
//                quando entro in una nuova riunione perdo i biglietti vecchi
                BigliettiLetti.removeAll()
                BigliettiLetti = leggiBiglietti(p: p, meetingCode: viewModel.meetingCode ,bigliettiScartati: BigliettiScartati, bigliettiSalvati: bigliettiSalvati, bigliettoDefault: bigliettoDefault)
                print("...dopo")
            }else{
                print("nessun meetingCode!")
            }
            
            
        }
        .onReceive(timer1){ date in
            if(viewModel.meetingCode != "") && (viewModel.goOut == "false"){
                if (bigliettoDefault.email != " ") && (bigliettoDefault.email != ""){
                    if(hoScritto == false){
                        scriviBiglietto(p: p, biglietto: bigliettoDefault, meetingcode: viewModel.meetingCode)
                        hoScritto = true
                    }
                }
            }
                else if (viewModel.goOut == "true"){
                    hoScritto = false
                    viewModel.goOut = "false"
                    viewModel.meetingCode = ""
                    
                }
            }
        .onAppear(){
            if tagExsists == false {
                mioTag = TagUnicoRiunione(p: p)
                tagExsists = true
                print("tagExsists: \(tagExsists)")
            }
        }
        
        }
        
    }



