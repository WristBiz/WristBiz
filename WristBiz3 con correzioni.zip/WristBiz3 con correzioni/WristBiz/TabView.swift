//
//  TabView.swift
//  carte
//
//  Created by Assunta Pia Clarino on 16/02/23.
//

import Foundation
import SwiftUI
import PhotosUI
import ParthenoKit

struct MyTabView: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    @State var personalData = IstanzeBigliettoAziendale()
    @State private var selectedTab = 0
    @StateObject var viewModel = iPhoneViewModel()
    @State private var bigliettiSalvati : [IstanzeBigliettoAziendale] = []
    //    {
    //        get
    //        {
    //            let data = UserDefaults.standard.data(forKey: "bigliettiSalvati")
    //            if let data = data{
    //                let decoder = JSONDecoder()
    //                return (try? decoder.decode([IstanzeBigliettoAziendale].self, from: data))  ?? [IstanzeBigliettoAziendale]()
    //            }
    //            return [IstanzeBigliettoAziendale]()
    //        }
    //        set {
    //            //            let data = try? JSONEncoder().encode(newValue)
    //            //            UserDefaults.standard.set(data, forKey: "bigliettiSalvati")
    //            //        }
    //            //    }
    //            let encoder = JSONEncoder()
    //            if let encodedData = try? encoder.encode(bigliettiSalvati) {
    //                UserDefaults.standard.set(encodedData, forKey: "bigliettiSalvati")
    //            }
    //        }
    //    }
    
    @State private var bigliettiScartati : [IstanzeBigliettoAziendale] = []
    @State private var BigliettiLetti: [IstanzeBigliettoAziendale] = []
    let timer = Timer.publish(every: 4, on: .main, in: .common).autoconnect()
    @State var p: ParthenoKit = ParthenoKit()
    @State var hoScritto: Bool = false
    var body: some View {
        
        TabView(selection: $selectedTab){
            NavigationStack {
                Wallet(viewModel: viewModel, currentCard: IstanzeBigliettoAziendale())
            }
            .tabItem {
                Text("Mine")
                Image(systemName: "shared.with.you")
                    .padding()
            }
//            .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
            .tag(0)
            
            Color.white
                .opacity(0.25)
                .edgesIgnoringSafeArea(.all)
                .overlay(
                    Wallet3( viewModel: viewModel, BigliettiLetti: BigliettiLetti, bigliettiSalvati: $bigliettiSalvati,bigliettiScartati: $bigliettiScartati)
                )
                .tabItem {
                    Text("Received")
                    Image(systemName: "tray.and.arrow.down")
                        .padding()
                }
                .tag(1)
            
            Color.white
                .opacity(0.25)
                .edgesIgnoringSafeArea(.all)
                .overlay(
                    RicevutiSalvati(bigliettiSalvati: $bigliettiSalvati)
                )
                .tabItem {
                    Text("Stored")
                    Image(systemName: "folder.badge.person.crop")
                        .padding()
                }
                .tag(2)
            
            Color.white
                .opacity(0.25)
                .edgesIgnoringSafeArea(.all)
                .overlay(
                    Riunioni(viewModel: viewModel)
                )
                .tabItem {
                    Text("Meetings")
                    Image(systemName: "list.number")
                        .padding()
                }
                .tag(3)
        }
//        .accentColor(Color(red: 0.000, green: 0.013, blue: 0.422))
        .toolbar(.visible, for: .tabBar)
        .toolbarBackground(Color(red: 0.000, green: 0.013, blue: 0.422), for: .tabBar)
//        .background(Color(red: 0.000, green: 0.013, blue: 0.422))
        
        .onReceive(timer) {
            _ in
            print("goOut: \(viewModel.goOut)")
            if(viewModel.meetingCode != "") && (viewModel.goOut == "false"){
                print("meeting code: \(viewModel.meetingCode)")
                print("...prima")
                BigliettiLetti.removeAll()
                BigliettiLetti.append(contentsOf: leggiBiglietti(p: p, meetingCode: viewModel.meetingCode ,bigliettiScartati: bigliettiScartati, bigliettiSalvati: bigliettiSalvati))
                print("...dopo")
            }else{
                print("nessun meetingCode!")
            }
            
            
        }
        .onAppear(){
            if(viewModel.meetingCode != "") && (viewModel.goOut == "false"){
                if(!hoScritto){
                    print("riunione: \(viewModel.meetingCode)")
                    scriviBiglietto(p: p, biglietto: bigliettoDefault, meetingcode: viewModel.meetingCode)
                    hoScritto = true
                }
            }
        }
        
    }
}
struct TabView_Previews: PreviewProvider {
    static var previews: some View {
        MyTabView()
    }
}

