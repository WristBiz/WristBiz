//
//  Wallet4.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 16/02/23.
//

import SwiftUI

struct CardHolderView: View {
    @State private var isExpanded = false

    var body: some View {
        VStack {
            HStack {
                Text("Portacarte")
                    .font(.title)
                    .fontWeight(.bold)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)

            CardView2(imageName: "card1", cardName: "Carta di credito", isExpanded: $isExpanded)
            CardView2(imageName: "card2", cardName: "Carta prepagata", isExpanded: $isExpanded)
            CardView2(imageName: "card3", cardName: "Carta di debito", isExpanded: $isExpanded)

            Spacer()
        }
        .animation(.spring())
    }
}

struct CardView2: View {
    let imageName: String
    let cardName: String
    @Binding var isExpanded: Bool

    var body: some View {
        VStack {
            Image(imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: isExpanded ? 200 : 100)
                .padding(.top, 10)

            Text(cardName)
                .font(.headline)
                .foregroundColor(.black)

            if isExpanded {
                Text("Dettagli sulla carta")
                    .foregroundColor(.gray)
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 10)
        .onTapGesture {
            withAnimation {
                isExpanded.toggle()
            }
        }
        .padding(.horizontal)
    }
}

struct Wallet4_Previews: PreviewProvider {
    static var previews: some View {
        CardHolderView()
    }
}
