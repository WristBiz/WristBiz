//
//  DatiRiunione.swift
//  WristBiz
//
//  Created by Marianna Nvarra on 06/03/23.
//

import SwiftUI
import ParthenoKit

struct DatiRiunione: View {
    @State var data: Data?
    @State private var isShown: Bool = false
    @Binding var isPresented: Bool
    @ObservedObject var viewModel: iPhoneViewModel
    @Binding var meets: [IstanzeRiunione]
    @Binding var codice: String
    @Binding var mioTag: String
    @State var meetData = IstanzeRiunione(nome: "", data: "", codice: " ")
    var body: some View {
        
        NavigationView{
            ZStack{
                Rectangle()
                    .opacity(0.1)
                    .background(Image("sfondo").opacity(0.2))

                ScrollView{
                    
                    VStack(alignment: .center){
                        Spacer()
                        Text("Enter meet data")
                            .padding(20)
                            .font(.custom("San Francisco", size: 30))
                            .bold()
                            .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
                        
                        TextField("Meet Name", text: $meetData.nome)
                            .padding()
                            .frame(width: 300, height: 50)
                            .background(Color.white.opacity(0.4))
                            .cornerRadius(10)
                        TextField("MM-DD-YYYY (*)", text: $meetData.data)
                            .padding()
                            .frame(width: 300, height: 50)
                            .background(Color.white.opacity(0.4))
                            .cornerRadius(10)
                        Text("meeting code: \(codice)")
                            .padding()
                            .frame(width: 300, height: 50)
                            .background(Color.white.opacity(0.4))
                            .cornerRadius(10)
                        
                        ZStack{
                            Rectangle()
                                .opacity(0.1)
                                .frame(width: 60, height: 40)
                                .background(Color(red: 0.000, green: 0.013, blue: 0.422))
                                .cornerRadius(20)
                            NavigationLink(destination:{
                                RiunioneCreata(viewModel: viewModel, isPresented: $isPresented, meet: meetData, codice: $codice, meets: $meets, mioTag: $mioTag)
                            }, label: {
                                Text("Next").foregroundColor(.white)
                                
                            }).padding(20)
                        }
                    }
                    
                }
            }
        }
    }
}

struct RiunioneCreata: View{
    @ObservedObject var viewModel: iPhoneViewModel
    @Binding var isPresented: Bool
    @State var meet: IstanzeRiunione
    @Binding var codice: String
    @Binding var meets: [IstanzeRiunione]
    @State var p: ParthenoKit = ParthenoKit()
    @Binding var mioTag: String
    var body: some View{
        ZStack{
            Rectangle()
                .opacity(0.01)
                .background(Image("sfondo").opacity(0.2))
            
            
                .overlay{
                    
                    VStack{
                        Text("Meeting Name:").font(.custom("San Francisco", size: 20))
                        Text(meet.nome).font(.custom("San Francisco", size: 30))
                            .bold()
                        Text(" ")
                        Text("Meeting Date:").font(.custom("San Francisco", size: 20))
                        Text(meet.data).font(.custom("San Francisco", size: 30))
                        Text(" ")
                        Text("Meeting code:").font(.custom("San Francisco", size: 20))
                        Text(codice).font(.custom("San Francisco", size: 30))
                    }
                }
            
                .padding()
            
            
            
                .navigationBarItems(trailing: Button(action: {
                    let meet = IstanzeRiunione(nome: meet.nome, data: meet.data, codice: codice)
                    meets.append(meet)
                    scriviRiunione(p: p, riunione: meet, mioTag: mioTag)
                    isPresented = false
                }, label: {
                    Text("Done")
                }))
            
            
        }
}
}


