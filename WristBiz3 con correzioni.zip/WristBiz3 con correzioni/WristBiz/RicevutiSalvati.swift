//
//  RicevutiSalvati.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 15/02/23.
//

import SwiftUI

struct RicevutiSalvati: View {
    @State private var searchText = ""
    @State var text = ""
    @Binding var bigliettiSalvati: [IstanzeBigliettoAziendale]
    var body: some View {
        ZStack{
            Rectangle()
                .opacity(0.01)
                .background(Image("sfondo").opacity(0.5))
            
            HStack{
                VStack (alignment: .leading){
                    Text("Stored")
                        .font(.custom("San Francisco", size: 50))
                        .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
                        
                    ScrollView{
                        VStack(alignment: .center){
                            ForEach(bigliettiSalvati) { biglietto in
                                BigliettoImage(biglietto: biglietto)
                            }
                        }
                    }
                }
                
            }
            VStack(){
                Spacer()
                HStack {
                    Spacer()
//                    FilterView()
                    
                }.searchable(text: $text)
                
            }
        }.padding(15)
    }
}

struct BarraDiRicerca: View {
    @State private var searchText = ""
    var body: some View {
        VStack {
            SearchBar(text: $searchText)
        }
    }
}

struct SearchBar: View {
    @Binding var text: String
    var body: some View {
        HStack {
            TextField("Search...", text: $text)
                .padding(7)
                .background(Color(.systemGray6))
                .cornerRadius(8)
                .padding(.horizontal, 15)
            
            Button(action: {
                self.text = ""
            }) {
                Image(systemName: "xmark.circle.fill")
                    .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
            }
        }
    }
}

struct FilterView: View {
    @State private var isFilterVisible = false
    @State private var selectedDate = Date()
    
    var body: some View {
        VStack {
            Button(action: {
                isFilterVisible.toggle()
            }) {
                Image(systemName: "calendar.badge.clock" ).foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
            }
            .padding()
            .sheet(isPresented: $isFilterVisible, content: {
                VStack {
                    DatePicker("Select date", selection: $selectedDate, displayedComponents: .date).foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
                        .datePickerStyle(GraphicalDatePickerStyle())
                        .padding(.vertical, 10)
                    
                    Button("Apply Filter") {
                        isFilterVisible.toggle()
                    }
                    .foregroundColor(.white)
                    .padding()
                    .background(Color(red: 0.000, green: 0.013, blue: 0.422))
                    .cornerRadius(10)
                    .padding(.top, 10)
                }
                .foregroundColor(.white)
                .padding(.vertical, 10)
                .padding(.horizontal, 20)
                .background(Color.white.opacity(0.2))
                .cornerRadius(10)
            })
        }
    }
}


