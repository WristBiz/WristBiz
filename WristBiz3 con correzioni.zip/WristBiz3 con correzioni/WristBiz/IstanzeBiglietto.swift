//
//  IstanzeBiglietto.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 14/02/23.
//

import SwiftUI

var i : Int=0

class IstanzeBigliettoAziendale: Hashable, Identifiable, Codable {
    
    var id = UUID()
    var azienda: String = " "
    var ruolo: String = " "
    var nome: String = " "
    var cognome: String = " "
    var numero: String = " "
    var email: String = " "
    var indice : Int = 0
    var Accettato: Bool = false
    
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(azienda)
        hasher.combine(ruolo)
        
    }
    init(azienda: String, ruolo: String, nome: String, cognome: String, numero: String, email: String) {
        self.azienda = azienda
        self.ruolo = ruolo
        self.nome = nome
        self.cognome = cognome
        self.numero = numero
        self.email = email
        self.indice = i+1
        i = i+1
        
    }
    
    init() {
        self.indice = i+1
        i = i+1
    }
    
    static func == (lhs: IstanzeBigliettoAziendale, rhs: IstanzeBigliettoAziendale) -> Bool {return true}
    
    
    func diverso(biglietto2: IstanzeBigliettoAziendale)-> Bool{
        if ((self.nome == biglietto2.nome) && (self.cognome == biglietto2.cognome) && (self.email == biglietto2.email)) {
            return false
        }else{
            return true
        }
    }
    
}


typealias ArrayBiglietti = [IstanzeBigliettoAziendale]


extension ArrayBiglietti: RawRepresentable {
    public init?(rawValue: String) {
        guard let data = rawValue.data(using: .utf8),
              let result = try? JSONDecoder().decode(ArrayBiglietti.self, from: data)
        else {
            return nil
            
        }
        self = result
        
    }
    public var rawValue: String {
        guard let data = try? JSONEncoder().encode(self),
                let result = String(data: data, encoding: .utf8)
        else {
            return "[]"
            
        }
        return result
        
    }
    
}

typealias StringToSave = String


extension StringToSave: RawRepresentable{
    public init?(rawValue: String) {
        guard let data = rawValue.data(using: .utf8),
              let result = try? JSONDecoder().decode(StringToSave.self, from: data)
        else {
            return nil
            
        }
        self = result
        
    }
    public var rawValue: String {
        guard let data = try? JSONEncoder().encode(self),
                let result = String(data: data, encoding: .utf8)
        else {
            return "[]"
            
        }
        return result
        
    }
    
}



typealias BoolToSave = Bool


extension BoolToSave: RawRepresentable{
    public init?(rawValue: String) {
        guard let data = rawValue.data(using: .utf8),
              let result = try? JSONDecoder().decode(BoolToSave.self, from: data)
        else {
            return nil
            
        }
        self = result
        
    }
    public var rawValue: String {
        guard let data = try? JSONEncoder().encode(self),
                let result = String(data: data, encoding: .utf8)
        else {
            return "[]"
            
        }
        return result
        
    }
    
}




//typealias BigliettoD = IstanzeBigliettoAziendale
//
//
//extension BigliettoD: RawRepresentable {
//    public init?(rawValue: String) {
//        guard let data = rawValue.data(using: .utf8),
//              let result = try? JSONDecoder().decode(BigliettoD.self, from: data)
//        else {
//            return nil
//            
//        }
//        self = result
//        
//    }
//    public var rawValue: String {
//        guard let data = try? JSONEncoder().encode(self),
//                let result = String(data: data, encoding: .utf8)
//        else {
//            return "[]"
//            
//        }
//        return result
//        
//    }
//    
//}
