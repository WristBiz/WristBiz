//
//  ReadAndWrite.swift
//  WristBiz
//
//  Created by Marianna Nvarra on 22/02/23.
//

import Foundation
import ParthenoKit
import SwiftUI

//    MARK: Read from ParthenoKit



func leggiBiglietti(p: ParthenoKit, meetingCode: String, bigliettiScartati: [IstanzeBigliettoAziendale], bigliettiSalvati : [IstanzeBigliettoAziendale], bigliettoDefault: IstanzeBigliettoAziendale)-> [IstanzeBigliettoAziendale]{
    var scartaBiglietti: [IstanzeBigliettoAziendale] = []
    var value: String
    var count : Int = 0
    let resultt = p.readSync(team: "TeamB2122S678AM", tag: meetingCode, key: "%")
    for (_, val) in resultt {
        count+=1
        print("\(count)")
        let biglietto: IstanzeBigliettoAziendale = IstanzeBigliettoAziendale()
        value = val
        var Space = value.firstIndex(of: ",") ?? value.startIndex
        biglietto.azienda = String(value[..<Space])
        value.removeFirst(biglietto.azienda.count+1)
        
        Space = value.firstIndex(of: ",") ?? value.startIndex
        biglietto.ruolo = String(value[..<Space])
        value.removeFirst(biglietto.ruolo.count+1)
        
        Space = value.firstIndex(of: ",") ?? value.startIndex
        biglietto.nome = String(value[..<Space])
        value.removeFirst(biglietto.nome.count+1)
        
        Space = value.firstIndex(of: ",") ?? value.startIndex
        biglietto.cognome = String(value[..<Space])
        value.removeFirst(biglietto.cognome.count+1)
        
        Space = value.firstIndex(of: ",") ?? value.startIndex
        biglietto.numero = String(value[..<Space])
        value.removeFirst(biglietto.numero.count+1)
        
        biglietto.email = String(value)
        value.removeFirst(biglietto.email.count)
        
        if biglietto.email != " " {
            if biglietto.email != "" {
                if bigliettoDefault.email != biglietto.email{
                    if !contiene(biglietto: biglietto, biglietti: bigliettiScartati){
                        if !contiene(biglietto: biglietto, biglietti: bigliettiSalvati){
                            if !contiene(biglietto: biglietto, biglietti: scartaBiglietti){
                                scartaBiglietti.append(biglietto)
                            }
                        }
                    }
                }
            }
        }
    }
    return scartaBiglietti
}


func contiene(biglietto: IstanzeBigliettoAziendale, biglietti: [IstanzeBigliettoAziendale]) -> Bool {
    var isContenuto = false
    
    for bigliettoScartato in biglietti {
        if biglietto.email == bigliettoScartato.email {
            isContenuto = true
            break
        }
    }
    
    return isContenuto
}



//    MARK: Write in ParthenoKit
func scriviBiglietto(p: ParthenoKit, biglietto: IstanzeBigliettoAziendale, meetingcode: String){
    var value: String
    let today = Date.now
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .medium
    
    value = biglietto.azienda + "," + biglietto.ruolo + "," + biglietto.nome + "," + biglietto.cognome + "," + biglietto.numero + "," + biglietto.email
    
    let resultt = p.writeSync(team: "TeamB2122S678AM", tag: meetingcode, key: biglietto.nome+biglietto.cognome+formatter.string(from: today), value: value)
    if resultt == false {
        print("errore durante l'invio del biglietto")
    }else{
        print("invio del biglietto andato a buon fine \(value)")
        print("riunione \(meetingcode)")
    }
}



func leggiRiunioni(p: ParthenoKit, mioTag: String)-> [IstanzeRiunione]{
    var riunioniLette: [IstanzeRiunione] = []
    var value: String
    var count : Int = 0
    let resultt = p.readSync(team: "TeamB2122S678AM", tag: mioTag, key: "%")
    for (_, val) in resultt {
        count+=1
        print("\(count)")
        let riunione: IstanzeRiunione = IstanzeRiunione()
        value = val
        var Space = value.firstIndex(of: ",") ?? value.startIndex
        riunione.nome = String(value[..<Space])
        value.removeFirst(riunione.nome.count+1)
        
        Space = value.firstIndex(of: ",") ?? value.startIndex
        riunione.data = String(value[..<Space])
        value.removeFirst(riunione.data.count+1)
        
        riunione.codice = String(value)
        value.removeFirst(riunione.codice.count)
        
        if (riunione.data != "") && (riunione.data != " ") {
            if !contieneR(riunione: riunione, riunioni: riunioniLette){
                riunioniLette.append(riunione)
            }
        }
        
        
    }
    return riunioniLette
}

func contieneR(riunione: IstanzeRiunione, riunioni: [IstanzeRiunione]) -> Bool {
    var isContenuto = false
    
    for riunioneS in riunioni {
        if riunioneS.nome == riunione.nome {
            isContenuto = true
            break
        }
    }
    
    return isContenuto
}


func scriviRiunione(p: ParthenoKit, riunione: IstanzeRiunione, mioTag: String){
    var value: String
    let today = Date.now
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .medium
    
    value = riunione.nome + "," + riunione.data + "," + riunione.codice
    
    let resultt = p.writeSync(team: "TeamB2122S678AM", tag: mioTag, key: riunione.nome+formatter.string(from: today), value: value)
    if resultt == false {
        print("errore durante l'invio della riunione")
    }else{
        print("invio della riunione andato a buon fine")
        print("riunione: \(value)")
        print("mioTag: \(mioTag)")
    }
}

func TagUnicoRiunione(p: ParthenoKit)->String{
    var value: String
    var numero: String
    var mioTag: String = ""
    
    let valore = p.readSync(team: "TeamB2122S678AM", tag: "000002", key: "%")
    
    for (_, val) in valore {
        var x:Int = Int(val) ?? 0
        mioTag = String(x)
        x = x + 1
        numero = String(x)
        
        let resultt = p.writeSync(team: "TeamB2122S678AM", tag: "000002", key:"TagUnivoco", value: numero)
    }
    return mioTag
}
