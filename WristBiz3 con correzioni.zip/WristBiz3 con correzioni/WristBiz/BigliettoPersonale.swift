//
//  Biglietto.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 14/02/23.
//

//import SwiftUI
//
//struct BigliettoPersonale: View {
//    var personalData: IstanzeBiglietto
//    
//    var body: some View {
//        
//        ZStack{
//            Rectangle()
//                .foregroundColor(Color(hue: 0.129, saturation: 0.236, brightness: 0.979))
//                .padding(-100)
//            VStack{
//                Text("Nome: \(personalData.nome)")
//                Text("Cognome: \(personalData.cognome)")
//                Text("Numero: \(personalData.numero)")
//                Text("Email: \(personalData.email)")
//            }
//            
//        }
//    }
//}

//struct BigliettoPersonale_Previews: PreviewProvider {
//    static var previews: some View {
//        BigliettoPersonale()
//    }
//}
