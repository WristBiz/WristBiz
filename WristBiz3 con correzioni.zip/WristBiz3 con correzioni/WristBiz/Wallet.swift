//
//  Home.swift
//  WalletUI
//
//  Created by Shameem Reza on 13/3/22.
//

import SwiftUI
import WatchConnectivity

var bigliettoDefault: IstanzeBigliettoAziendale = IstanzeBigliettoAziendale()

struct Wallet: View {
    @State var cards: [IstanzeBigliettoAziendale] = []
    @State var expandCards: Bool = false
    @ObservedObject var viewModel: iPhoneViewModel
    @State var currentCard: IstanzeBigliettoAziendale
    @State var showDetailTransaction: Bool = false
    @Namespace var animation
    @State private var selectedCard = -1
    @State private var isCardSelected = true
    @State var count: Int = 1
    @State var Count: Int = 0
    @State var isAddingCard = false
    
    var body: some View {
        NavigationView{
            ZStack{
                Rectangle()
                    .opacity(0.01)
                    .background(Image("sfondo").opacity(0.25))
                VStack() {
                    Text("My Visit Cards")
                        .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
                        
                        .font(.custom("San Francisco", size: 50))
                        
                        .frame(maxWidth: .infinity, alignment: expandCards ? .leading : .center)
                        
                        .overlay(alignment: .trailing) {
                            // MARK: CLOSE BUTTON
                            Button {
                                withAnimation(
                                    .interactiveSpring(response: 0.8, dampingFraction: 0.7, blendDuration: 0.7)) {
                                        expandCards = false
                                    }
                            } label: {
                                Image(systemName: "arrow.up")
                                    .foregroundColor(.white)
                                    .padding(10)
                                    .background(Color(red: 0.000, green: 0.013, blue: 0.422), in: Circle())
                            }
                            
                            .offset(x: expandCards ? 10 : 15)
                            .opacity(expandCards ? 1 : 0)
                        }
                    
                        .padding(.horizontal, 15)
                        .padding(.bottom, 10)
                    
                    

                    ScrollView {
                        HStack(alignment: .center){
                            VStack(alignment: .leading){
                            ForEach(cards) {card in
                                CardView(card: card, cardIndex : card.indice)
                                    .onTapGesture {
                                        withAnimation(.easeInOut(duration: 0.35)) {
                                            currentCard = card
                                        }
                                    }
                                
                            }
                                
                        }
                    }
                        .overlay {
                            Rectangle()
                                .fill(.black.opacity(expandCards ? 0 : 0.01))
                                .frame(width: 1000, height: 1000)
                                .onTapGesture {
                                    withAnimation(.easeInOut(duration: 0.35)) {
                                        expandCards = true
                                    }
                                    
                                }
                        }
                        VStack(){
                            Spacer()
                            Button(action: {
                                isAddingCard.toggle()
                            }, label: {
                                Image(systemName: "plus")
                                    .font(.title)
                                    .foregroundColor(.white)
                                    .padding(20)
                                    .background(Color(red: 0.000, green: 0.013, blue: 0.422), in: Circle())
                            })
                            
                            .scaleEffect(expandCards ? 0.01 : 1)
                            .opacity(!expandCards ? 1 : 0)
                            .frame(height: expandCards ? 0 : nil)
                            .padding(.bottom, expandCards ? 0 : 30)
                        }
                    }
                    .coordinateSpace(name: "SCROLL")
                    .offset(y: expandCards ? 0 : 30)
                    
                }
//                .padding([.horizontal, .top])
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .overlay {
                    if var currentCard = currentCard, showDetailTransaction {
                        TransactionView(currentCard: currentCard, showDetailTransaction: $showDetailTransaction, animation: animation)
                    }
                }
            }
            .sheet(isPresented: $isAddingCard, content: {
                DatiAzienda(isPresented: $isAddingCard, viewModel: viewModel, cards: $cards)
            })
        }
    }
    // MARK: CARD VIEW
    @ViewBuilder
    func CardView(card: IstanzeBigliettoAziendale, cardIndex: Int)->some View {
        GeometryReader {proxy in
            
            let rect = proxy.frame(in: .named("SCROLL"))
            let offset = CGFloat(getIndex(Card: card) * (expandCards ? 10 : 70))
            
            Button(action: {
                self.selectedCard = cardIndex
                self.isCardSelected = true
                count = cardIndex
                print(offset)
                bigliettoDefault = card
            }) {
                BigliettoImage(biglietto: card)
                    .frame(width: 350, height: 250)
                    .cornerRadius(25)
                    .overlay(
                        RoundedRectangle(cornerRadius: 25,style: .circular)
                            
                            .stroke(cardIndex == selectedCard && isCardSelected ? Color(red: 0.000, green: 0.013, blue: 0.422) : Color.clear, lineWidth: 4)
                            .animation(.default, value: 2 )
                    )
                
            }.opacity(isCardSelected ? 1 : 0)
                .animation(.default, value: 2 )
            
                .offset(y: expandCards ? offset : -rect.minY + offset)
        }
        .frame(height: expandCards ? 250 : 125)
        .padding(.horizontal)
    }
    
    // MARK: - GET CARD INDEX NUMBER
    func getIndex(Card: IstanzeBigliettoAziendale)-> Int {
        return cards.firstIndex { currentCard in
            return currentCard.id == Card.id
        } ?? 0
    }
}

// MARK: - HIDE FIRST FEW DIGIT
func hideCardNumber(number: String)->String {
    var newValue: String = ""
    let maxCount = number.count - 4
    
    number.enumerated().forEach {value in
        if value.offset >= maxCount {
            let string = String(value.element)
            newValue.append(contentsOf: string)
            
        } else {
            // MARK: - SHOW START
            let string = String(value.element)
            if string == " " {
                newValue.append(contentsOf: " ")
            } else {
                newValue.append(contentsOf: "*")
            }
        }
    }
    return newValue
}

struct Home_Previews: PreviewProvider {
    var biglietto: IstanzeBigliettoAziendale
    static var previews: some View {
        Wallet(viewModel: iPhoneViewModel(), currentCard: IstanzeBigliettoAziendale())
    }
}


// MARK: DETAIL TRANSACITON VIEW

struct TransactionView: View {
    var currentCard: IstanzeBigliettoAziendale
    @Binding var showDetailTransaction: Bool
    // MARK: GEOMETRY EFFECT
    var animation: Namespace.ID
    
    // MARK: DELAY EXPENSE VIEW
    @State var showExpenseView: Bool = false
    
    var body: some View {
        VStack (alignment: .center){
            CardView()
                .matchedGeometryEffect(id: currentCard.id, in: animation)
                .frame(height: 200)
                .onTapGesture {
                    withAnimation(.easeInOut) {
                        showExpenseView = false
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                        withAnimation(.easeInOut(duration: 0.35)) {
                            showDetailTransaction = false
                        }
                    }
                    
                }
                .zIndex(10)
            
            GeometryReader {proxy in
                let height = proxy.size.height + 50
                ScrollView(.vertical, showsIndicators: false) {
                }
                .frame(maxWidth: .infinity)
                .background(
                    Color.white
                        .clipShape(RoundedRectangle(cornerRadius: 25, style: .continuous))
                        .ignoresSafeArea()
                )
                .offset(y: showExpenseView ? 0 : height)
            }
            .padding([.horizontal, .top])
            .zIndex(-10)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .background(Color("ColorBG").ignoresSafeArea())
        .onAppear {
            withAnimation(.easeInOut.delay(0.1)) {
                showExpenseView = true
            }
        }
    }
    
    @ViewBuilder
    func CardView()->some View {
        ZStack(alignment: .bottomLeading) {
            
        }
    }
}


