//
//  Wallet3.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 11/02/23.
//

import SwiftUI
import WatchConnectivity
import ParthenoKit
//var BigliettiSalvati : [IstanzeBigliettoAziendale] = []

struct Wallet3: View {
    @ObservedObject var viewModel: iPhoneViewModel
    @Binding var BigliettiLetti: [IstanzeBigliettoAziendale]
    var p: ParthenoKit = ParthenoKit()
    @Binding var bigliettiSalvati : [IstanzeBigliettoAziendale]
    @Binding var bigliettiScartati : [IstanzeBigliettoAziendale]
    
    var body: some View {
       
        ZStack{
            Rectangle()
                .opacity(0.01)
                .background(Image("sfondo").opacity(0.5))
            VStack{
                HStack{
                    Text("Received")
                        .font(.custom("San Francisco", size: 50))
                        .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
                        .padding()
                    Spacer()
                }
                if BigliettiLetti.count>0{
                    List(BigliettiLetti){ biglietto in
                        BigliettoImage(biglietto: biglietto)
                            .listRowBackground(Color.clear)
                            .listRowSeparator(.hidden)
                            .cornerRadius(20)
                            .swipeActions(edge: .trailing, allowsFullSwipe: true, content: {
                                Button(action: {
                                    bigliettiSalvati.append(biglietto)
                                    let indice = biglietto.indice
                                    for i in 0..<BigliettiLetti.count{
                                        if BigliettiLetti[i].indice == indice{
                                            print("i: \(i)")
                                            print("indice: \(indice)")
                                            BigliettiLetti.remove(at: i)
                                            
                                            break
                                        }
                                    }
                                    
                                }, label: {
                                    Text("Save")
                                    
                                }).tint(.green)
                                    .background(Color(.green))
                            })
                            .swipeActions(edge: .leading, allowsFullSwipe: true, content: {
                                Button(action: {
                                    bigliettiScartati.append(biglietto)
                                    let indice = biglietto.indice
                                    for i in 0..<BigliettiLetti.count{
                                        if BigliettiLetti[i].indice == indice{
                                            print("i: \(i)")
                                            print("indice: \(indice)")
                                            BigliettiLetti.remove(at: i)
                                            break
                                        }
                                    }
                                    
                                }, label: {
                                    Text("Delete")
                                    
                                }).tint(.red)
                                    .background(Color(.red))
                            })
                    }.scrollContentBackground(.hidden)}
                Spacer()
            }
            }
        
    }
    
}

