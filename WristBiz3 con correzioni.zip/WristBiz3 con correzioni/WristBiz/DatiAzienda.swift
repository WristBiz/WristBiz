import SwiftUI
import PhotosUI

//var BigliettiMiei: [IstanzeBigliettoAziendale]


struct DatiAzienda: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    @State private var isShown: Bool = false
    @State private var sourceType: UIImagePickerController.SourceType = .camera
    @Binding var isPresented: Bool
    @ObservedObject var viewModel: iPhoneViewModel
    @State var personalData = IstanzeBigliettoAziendale(azienda: "", ruolo: "", nome: "", cognome: "", numero: "", email: "")
    @Binding var cards: [IstanzeBigliettoAziendale]
    
    var body: some View {
        NavigationView{
            ZStack{
                Rectangle().opacity(0.1)
                    .background(Image("sfondo").opacity(0.2))
                
                
                ScrollView{
                    
                    VStack(alignment: .center){
                        Spacer()
                        Text("Enter your data")
                            .padding(20)
                            .font(.custom("San Francisco", size: 30))
                            .bold()
                            .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
                        
                        TextField("Company Name", text: $personalData.azienda)
                            .padding()
                            .frame(width: 300, height: 50)
                            .background(Color.white.opacity(0.4))
                            .cornerRadius(10)
                        TextField("Job Position (*)", text: $personalData.ruolo)
                            .padding()
                            .frame(width: 300, height: 50)
                            .background(Color.white.opacity(0.4))
                            .cornerRadius(10)
                        TextField("Name (*)", text: $personalData.nome)
                            .padding()
                            .frame(width: 300, height: 50)
                            .background(Color.white.opacity(0.4))
                            .cornerRadius(10)
                        TextField("Last Name (*)", text: $personalData.cognome)
                            .padding()
                            .frame(width: 300, height: 50)
                            .background(Color.white.opacity(0.4))
                            .cornerRadius(10)
                        TextField("Number", text: $personalData.numero)
                            .padding()
                            .frame(width: 300, height: 50)
                            .background(Color.white.opacity(0.4))
                            .cornerRadius(10)
                        TextField("Email (*)", text: $personalData.email)
                            .padding().frame(width: 300, height: 50)
                            .background(Color.white.opacity(0.4))
                            .cornerRadius(10)
                        
                        ZStack{
                            
                            Rectangle()
                                .opacity(0.1)
                                .frame(width: 60,height: 40)
                                .background(Color(red: 0.000, green: 0.013, blue: 0.422))
                                .cornerRadius(20)
                            
                            NavigationLink(destination:{
                                BigliettoAziendale(viewModel: viewModel, isPresented: $isPresented, card: personalData, cards: $cards)
                            }, label: {
                                Text("Next").foregroundColor(.white)
                                
                            }).padding(20)
                        }
                    }
                    }
                }
                
                .onChange(of: selectedItems) {
                    newValue in guard let item = selectedItems.first else {
                        return
                    }
                    item.loadTransferable(type: Data.self) { result in switch result {
                    case .success(let data): if let data = data {
                        self.data = data
                    } else{
                        print("Data is nil")
                    }
                    case.failure(let failure): fatalError("failure")
                    }
                    }
                    
                    
                }
                
            
        }
    }
}



struct BigliettoAziendale:View{
    
    @ObservedObject var viewModel: iPhoneViewModel
    @Binding var isPresented: Bool
    var card: IstanzeBigliettoAziendale
    @Binding var cards: [IstanzeBigliettoAziendale]
    
    var body: some View{
        ZStack{
            Rectangle().opacity(0.1)
                .background(Image("sfondo").opacity(0.2))
            VStack(alignment: .center) {
                Image("Biglietto")
                    .resizable()
                    .scaledToFit()
                    .padding(.horizontal)
                
                    .overlay{
                        
                        VStack{
                            Text(card.nome + " " + card.cognome)
                                .foregroundColor(.black)
                            Text(card.numero)
                                .foregroundColor(.black)
                            Text(card.email)
                                .foregroundColor(.black)
                            Text(card.azienda)
                                .foregroundColor(.black)
                            Text(card.ruolo)
                                .foregroundColor(.black)
                        }.padding()
                    }
            }
            .navigationBarItems(trailing: Button(action: {
                let carta = IstanzeBigliettoAziendale(azienda: card.azienda, ruolo: card.ruolo, nome: card.nome, cognome: card.cognome, numero: card.numero, email: card.email)
                cards.append(carta)
                isPresented = false
            }, label: {
                Text("Done")
            }))
            
        }
        
    }
}

struct BigliettoAziendale3:View{
    @ObservedObject var viewModel: iPhoneViewModel
    var biglietto: IstanzeBigliettoAziendale
    @Binding var isPresented: Bool
    
    var body: some View{
        RoundedRectangle(cornerRadius: 25)
            .frame(width: 365, height: 250)
            .foregroundColor(Color.init(hex: "FFFFFF"))
            .border(.black)
            .cornerRadius(0)
            .overlay{
                
                VStack{
                    
                    HStack{
                        Spacer()
                        VStack{
                            Text(biglietto.nome + " " + biglietto.cognome)
                                .bold()
                        }
                    }
                    HStack{
                        Spacer()
                        VStack{
                            Text(biglietto.numero)
                        }
                    }
                    HStack{
                        VStack{
                            Text(biglietto.azienda)
                        }
                        Spacer()
                        VStack{
                            Text(biglietto.email)
                        }
                    }
                    HStack{
                        VStack{
                            Text(biglietto.ruolo)
                        }
                    
                    }
                    HStack{
                        Spacer()
                        
                    }
                }.padding()
            }
    }
}

struct ImagePicker: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    var body: some View {
        VStack{
            if let data = data, let uiimage = UIImage(data: data) { Image(uiImage: uiimage)
                    .resizable()
            }
            Spacer()
            PhotosPicker("Your Photo", selection: $selectedItems, maxSelectionCount: 1, matching: .images
            )
            .onChange(of: selectedItems) {
                newValue in guard let item = selectedItems.first else {
                    return
                }
                item.loadTransferable(type: Data.self) { result in switch result {
                case .success(let data): if let data = data {
                    self.data = data
                } else{
                    print("Data is nil")
                }
                case.failure(let failure): fatalError("failure")
                }
                }
            }
        }
    }
}
