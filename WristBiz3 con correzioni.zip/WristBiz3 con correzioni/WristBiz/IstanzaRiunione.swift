//
//  IstanzaRiunione.swift
//  WristBiz
//
//  Created by Marianna Nvarra on 06/03/23.
//

import SwiftUI



//JSONDecoder().decode([IstanzeBigliettoAziendale].self, from: var biglitto)

class IstanzeRiunione: Hashable, Identifiable, Codable {
    
    var id = UUID()
    var nome: String = " "
    var data: String = " "
    var codice: String = " "
    var indice : Int = 0
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(nome)
        hasher.combine(data)
        
    }
    init(nome: String, data: String, codice: String) {
        self.nome = nome
        self.data = data
        self.codice = codice
        self.indice = i+1
        i = i+1
        
    }
    
    init() {
        self.indice = i+1
        i = i+1
    }
    
    static func == (lhs: IstanzeRiunione, rhs: IstanzeRiunione) -> Bool {return true}
    
    
    func diverso(riunione2: IstanzeRiunione)-> Bool{
        if ((self.nome == riunione2.nome) && (self.data == riunione2.data)) {
            return false
        }else{
            return true
        }
    }
}
