//
//  MyTabView.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 16/02/23.
//

import SwiftUI

struct MyTabView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct MyTabView_Previews: PreviewProvider {
    static var previews: some View {
        MyTabView()
    }
}
