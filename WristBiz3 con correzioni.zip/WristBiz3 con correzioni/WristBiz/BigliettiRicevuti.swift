//
//  BigliettiRicevuti.swift
//  WalletUI
//
//  Created by Ciro Pazzi on 07/02/23.
//

import SwiftUI
import ParthenoKit

//
//struct BigliettiRicevuti: View {
//    public var ScartaBiglietti: [IstanzeBigliettoAziendale] = [IstanzeBigliettoAziendale()]
//    public var personalData: IstanzeBigliettoAziendale
//    @Binding var meetingCode: String
//    var body: some View {
//        VStack(alignment: .leading){
//            Text("Ricevuti")
//                .font(.title)
//                .bold()
//                .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
//
//            ZStack{
//                Rectangle()
//                    .opacity(0.01)
//                    .background(Image("sfondo").opacity(0.3))
//
//                VStack(alignment: .leading){
//                    Text("Non hai più Nuovi Biglietti da Visita Ricevuti!")
//                        .font(.title)
//                        .bold()
//                        .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
//                }.padding(15)
//                VStack(alignment: .center){
//                    ZStack {
//                        ForEach(ScartaBiglietti, id: \.self) { person in
//                            CardViewRicevuti(person: person, meetingCode: $meetingCode)
//                        }
//                    }
//
//                }
//            }
//        }.padding(15)
//    }
//}
//
//struct CardViewRicevuti: View {
//    @State var offset = CGSize.zero
//    @State var color: Color = Color(red: 0.000, green: 0.013, blue: 0.422)
//    @State var person: IstanzeBigliettoAziendale
//    @Binding var meetingCode: String
//    @State var BigliettiLetti: [IstanzeBigliettoAziendale] = [IstanzeBigliettoAziendale()]
//    var p: ParthenoKit = ParthenoKit()
//    var ind: Int = 0
//    var body: some View {
//        VStack{
//            Text(" ")
//        }
//        .onAppear {
//            //            MARK: Aggiustare "12345" in meetingCode
//
//            let timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
//                BigliettiLetti = leggiBiglietti(p: p, meetingCode: "12346",bigliettiScartati: BigliettiLetti,bigliettiSalvati: [IstanzeBigliettoAziendale()])
//                //                print(".....\(BigliettiLetti[2].nome)")
//            }
//            RunLoop.current.add(timer, forMode: .common)
//            if(bigliettoDefault.nome != " "){
//                scriviBiglietto(p: p, biglietto: bigliettoDefault, meetingcode: "12346")
//            }
//        }
//        VStack(alignment: .leading){
//            Text("Ricevuti")
//                .font(.title)
//                .bold()
//                .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
//            ScrollView{
//            ZStack{
//                Rectangle()
//                    .opacity(0.01)
//                    .background(Image("sfondo").opacity(0.3))
//
////                VStack(alignment: .leading){
////                    Text("Non hai più Nuovi Biglietti da Visita Ricevuti!")
////                        .font(.title)
////                        .bold()
////                        .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
////                }.padding(15)
//
//
//        }
//
//            VStack {
////                ForEach(0..<BigliettiLetti.count-2){ indd in
////                    var biglietto = IstanzeBigliettoAziendale()
////                    biglietto = BigliettiLetti[indd]
//                     ForEach(BigliettiLetti){ biglietto in
//                    //                    if (self.ind < BigliettiLetti.count-1){
//                    //                        self.ind = self.ind + 1
//                    if(biglietto.diverso(biglietto2: bigliettoDefault)){
//                        ZStack {
//                             Rectangle()
//                            .frame(width: 420, height: 320)
//                            .border(.white, width: 6.0)
//                             .cornerRadius(4)
//                            .foregroundColor(color.opacity(0.9))
//                             .shadow(radius: 4)
//                            BigliettoImage(biglietto: biglietto)
//                                .position(x: 205, y: 500)
//                                .offset(x: offset.width * 1, y: offset.height * 0.4)
//                                .rotationEffect(.degrees(Double(offset.width / 40)))
//                        }
//
//                        }
//                    }
//                    BigliettoImage(biglietto: BigliettiLetti[BigliettiLetti.count-1])
//                        .gesture(
//                            DragGesture()
//                                .onChanged { gesture in
//                                    offset = gesture.translation
//                                    withAnimation {
//                                        changeColor(width: offset.width)
//                                    }
//                                }
//                                .onEnded { _ in
//                                    withAnimation {
//                                        swipeCard(width: offset.width)
//                                        changeColor(width: offset.width)
//                                    }
//                                }
//                        )
//
//                    }
//
//                    }
//                }
//            }
//
//
//
//
//    func swipeCard(width: CGFloat) {
//        switch width {
//        case -500...(-150):
//            print("\(person) removed")
//            offset = CGSize(width: -500, height: 0)
//            person.Accettato = false
//        case 150...500:
//            print("\(person) added")
//            offset = CGSize(width: 500, height: 0)
//            person.Accettato = true
//            let bigliettoSalvato = IstanzeBigliettoAziendale(azienda: person.azienda, ruolo: person.ruolo, nome: person.nome, cognome: person.cognome, numero: person.numero, email: person.email)
//            BigliettiSalvati.append(bigliettoSalvato)
//
//        default:
//            offset = .zero
//        }
//    }
    
//    func changeColor(width: CGFloat) {
//        switch width {
//        case -500...(-130):
//            color = .red
//        case 130...500:
//            color = .green
//        default:
//            color = Color(red: 0.000, green: 0.013, blue: 0.422)
//        }
//    }
//    
//    
//}


struct Biglietto2View: View{
    @ObservedObject var viewModel: iPhoneViewModel
    var biglietti: [IstanzeBigliettoAziendale]
    var body: some View {
        List(biglietti){
            biglietto in
            BigliettoAziendale2(biglietto: biglietto)
            Spacer()
        }
    }
}


struct ImageOverlay: View {
    let biglietto: IstanzeBigliettoAziendale
    var body: some View {
       
            VStack{
                Text(biglietto.nome + " " + biglietto.cognome)
                    .foregroundColor(.black)
                Text(biglietto.numero)
                    .foregroundColor(.black)
                Text(biglietto.email)
                    .foregroundColor(.black)
                Text(biglietto.azienda)
                    .foregroundColor(.black)
                Text(biglietto.ruolo)
                    .foregroundColor(.black)
            }
        
        .background(Color.white)
        .opacity(0.8)
        .cornerRadius(10.0)
        
        
    }
    
}

struct BigliettoImage: View {
    let biglietto: IstanzeBigliettoAziendale
    var body: some View {
        VStack(alignment: .center) {
            Image("Biglietto")
                .resizable()
                .scaledToFit()
                .overlay(ImageOverlay(biglietto: biglietto), alignment: .center)
            
        }
    }
}

