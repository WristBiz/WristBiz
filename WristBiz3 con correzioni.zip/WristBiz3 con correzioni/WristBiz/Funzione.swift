//
//  Funzione.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 22/02/23.
//

//import SwiftUI
//import Foundation
//import ParthenoKit
//
//
//
//struct Scrivi: View {
//    @State private var counter = 0
//    var p: ParthenoKit = ParthenoKit()
//    @State var meetingCode: String
//    var body: some View {
//        var ScartaBiglietti: [IstanzeBiglietto] = [IstanzeBiglietto()]
//        VStack {
//            Text("Counter: \(counter)")
//                .padding()
//            Spacer()
//        }
//        .onAppear {
//            // Richiama la funzione "updateCounter" ogni 0.5 secondi
//           let timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
//               ScartaBiglietti = leggiBiglietti(p: p, meetingCode: meetingCode)
//
//            }
//
//            // Assicurati di fermare il timer quando la vista scompare
//            // per evitare memory leaks
//            RunLoop.current.add(timer, forMode: .common)
//        }
//        
//        NavigationView{
//            List(ScartaBiglietti){
//                biglietto in
//                NavigationLink(destination: BigliettoView(v: biglietto))
//                {
//                    BigliettoView2(v: biglietto)
//                }
//            }
//        }
//        
//    }
//    
//
//}
//
//struct BigliettoView: View{
//    @State var v: IstanzeBiglietto
//    var body: some View{
//        HStack{
//            Text("\(v.nome)")
//            Text("\(v.cognome)")
//            Text("\(v.numero)")
//            Text("\(v.email)")
//        }
//    }
//}
//struct BigliettoView2: View{
//    let v: IstanzeBiglietto
//    var body: some View{
//        HStack{
//            Text("\(v.nome)")
//            Text("\(v.cognome)")
//            Text("\(v.numero)")
//            Text("\(v.email)")
//        }
//    }
//}
