//
//  Riunioni.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 17/02/23.
//

import SwiftUI
import WatchConnectivity
import ParthenoKit

struct Riunioni: View {
    @ObservedObject var viewModel: iPhoneViewModel
    @State var codice: String = ""
    @State var meets: [IstanzeRiunione] = []
    @State var isAddingMeet = false
    @Binding var mioTag: String 
    @State var p: ParthenoKit = ParthenoKit()
    var body: some View {
        NavigationView{
            ZStack{
                Rectangle()
                    .opacity(0.01)
                    .background(Image("sfondo").opacity(0.5))
                VStack{
                    VStack(alignment: .leading){
                        HStack{
                            Text("Meetings")
                                .font(.custom("San Francisco", size: 50))
                                .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
                            Spacer()
                            ZStack{
                                Rectangle()
                                    .opacity(0.1)
                                    .frame(width: 80, height: 50)
                                    .background(Color(red: 0.000, green: 0.013, blue: 0.422))
                                    .cornerRadius(20)
                                
                                NavigationLink(destination: {
                                    OldMeeting(mioTag: mioTag)
                                }, label: {
                                    Text("Archivied")
                                        .foregroundColor(.white)
                                })
                            }
                        }
                        Text("In this section you can generate a random code for creating the virtual room.")
                            .font(.custom("San Francisco", size: 25))
                            .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
                    }
                    Spacer()
                    VStack(alignment: .center){

                        
                            
                            Button(action: {
                                codice=generateCode()
                                isAddingMeet.toggle()
                                print("meetingcode: \(viewModel.meetingCode)")
                            }, label: {
                                Text("Create meeting")
                                    .font(.custom("San Francisco", size: 25))
                                    .foregroundColor(.white)
                                    .padding(20)
                                    .background(Color(red: 0.000, green: 0.013, blue: 0.422), in: Rectangle())
                                    .cornerRadius(15)
                                
                            })
                            .padding(30)
                        
                    }
                }
            }.sheet(isPresented: $isAddingMeet, content: {
                DatiRiunione(isPresented: $isAddingMeet, viewModel: viewModel, meets: $meets, codice: $codice, mioTag: $mioTag)
            })
            .padding()
        }
       
    }
}


func generateCode() -> String {
    let code = String(format: "%04d", Int.random(in: 0...9999))
    return code
}




struct BigliettoView: View{
    @State var v: IstanzeBigliettoAziendale
    var body: some View{
        HStack{
            Text("\(v.azienda)")
            Text("\(v.ruolo)")
            Text("\(v.nome)")
            Text("\(v.cognome)")
            Text("\(v.numero)")
            Text("\(v.email)")
        }
    }
}
struct BigliettoView2: View{
    let v: IstanzeBigliettoAziendale
    var body: some View{
        HStack{
            Text("\(v.azienda)")
            Text("\(v.ruolo)")
            Text("\(v.nome)")
            Text("\(v.cognome)")
            Text("\(v.numero)")
            Text("\(v.email)")
        }
    }
}

struct OldMeeting: View {
    @State var meetings: [IstanzeRiunione] = []
    @State var p: ParthenoKit = ParthenoKit()
    @State var mioTag: String
    var body: some View{
        ZStack{
            Rectangle()
                .opacity(0.01)
                .background(Image("sfondo").opacity(0.5))
            VStack{
                
                List(meetings) { meet in
                    HStack{
                        Text(meet.nome)
                        Text("-")
                        Text(meet.codice)
                        Text("-")
                        Text(meet.data)
                        
                    }
//                    .listRowBackground(Color.clear)
//                        .listRowSeparator(.hidden)
                }.scrollContentBackground(.hidden)
            }
        }
        .onAppear(){
            meetings = leggiRiunioni(p: p,mioTag: mioTag)
        }
    }
}


