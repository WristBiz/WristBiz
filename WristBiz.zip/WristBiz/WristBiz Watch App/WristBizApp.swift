//
//  WristBizApp.swift
//  WristBiz Watch App
//
//  Created by Ciro Pazzi on 10/02/23.
//

import SwiftUI

@main
struct WristBiz_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
