//
//  BigliettiRicevuti.swift
//  WalletUI
//
//  Created by Ciro Pazzi on 07/02/23.
//

import SwiftUI

struct BigliettiRicevuti: View {
    private var people: [String] = ["Mario", "Luigi", "Peach", "Toad", "Daisy"].reversed()
    var body: some View {
        ZStack{
            Rectangle()
                .foregroundColor(Color(hue: 0.129, saturation: 0.236, brightness: 0.979))
                .padding(-100)
//            Circle()
//                .foregroundColor(Color(hue: 1.0, saturation: 0.077, brightness: 0.296))
//                .padding(-90)
//            Circle()
//                .foregroundColor(Color(hue: 0.118, saturation: 0.422, brightness: 0.959))
//                .padding(-80)
//            Circle()
//                .foregroundColor(Color(hue: 0.982, saturation: 0.15, brightness: 0.318))
//                .padding(-50)
//            Circle()
//                .foregroundColor(.white)
//                .padding(-40)
            Text("Non hai più Nuovi Biglietti da Visita Ricevuti!")
                .font(.title)
                .bold()
                .padding(20)
                .foregroundColor(.black)
                
            VStack {
                ZStack {
                    ForEach(people, id: \.self) { person in
                        CardView(person: person)
                    }
                }
            }
        }
    }
}


struct CardView: View {
    @State private var offset = CGSize.zero
    @State private var color: Color = .yellow
    var person: String
    
    var body: some View {
        ZStack {
            Rectangle()
                .frame(width: 420, height: 320)
                .border(.white, width: 6.0)
                .cornerRadius(4)
                .foregroundColor(color.opacity(0.9))
                .shadow(radius: 4)
            HStack {
//                Text(person)
//                    .font(.largeTitle)
//                    .foregroundColor(.white)
//                    .bold()
//                Image(systemName: "heart.fill")
//                    .foregroundColor(.red)
                Image("card1")
                    
            }
            
        }
        .offset(x: offset.width * 1, y: offset.height * 0.4)
        .rotationEffect(.degrees(Double(offset.width / 40)))
        .gesture(
            DragGesture()
                .onChanged { gesture in
                    offset = gesture.translation
                    withAnimation {
                        changeColor(width: offset.width)
                    }
                }
                .onEnded { _ in
                    withAnimation {
                        swipeCard(width: offset.width)
                        changeColor(width: offset.width)
                    }
                }
        )
    }
    
    func swipeCard(width: CGFloat) {
        switch width {
        case -500...(-150):
            print("\(person) removed")
            offset = CGSize(width: -500, height: 0)
        case 150...500:
            print("\(person) added")
            offset = CGSize(width: 500, height: 0)
        default:
            offset = .zero
        }
    }
    
    func changeColor(width: CGFloat) {
        switch width {
        case -500...(-130):
            color = .red
        case 130...500:
            color = .green
        default:
            color = .yellow
        }
    }
    
    
}

//struct CardView_Previews: PreviewProvider {
//    static var previews: some View {
//        CardView(person: "Mario")
//    }
//}

struct BigliettiRicevuti_Previews: PreviewProvider {
    static var previews: some View {
        BigliettiRicevuti()
    }
}


