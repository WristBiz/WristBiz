//
//  CreaBiglietto.swift
//  WalletUI
//
//  Created by Ciro Pazzi on 07/02/23.
//

import SwiftUI
import PhotosUI
struct CreaBiglietto: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    @State private var isShown: Bool = false
    @State private var sourceType: UIImagePickerController.SourceType = .camera
    @State private var nome = ""
    @State private var cognome = ""
    @State private var numero = ""
    @State private var email = ""
    var body: some View {
            
            ZStack{
                Rectangle()
                    .foregroundColor(Color(hue: 0.129, saturation: 0.236, brightness: 0.979))
                    .padding(-100)
                //        Circle()
                //            .foregroundColor(Color(hue: 1.0, saturation: 0.077, brightness: 0.296))
                //            .padding(-90)
                //        Circle()
                //            .foregroundColor(Color(hue: 0.118, saturation: 0.422, brightness: 0.959))
                //            .padding(-80)
                //        Circle()
                //            .foregroundColor(Color(hue: 0.982, saturation: 0.15, brightness: 0.318))
                //            .padding(-50)
                //        Circle()
                //            .foregroundColor(.white)
                //            .padding(-40)
                VStack{
                    Text("Crea il Tuo Biglietto da Visita")
                        .font(.title)
                        .bold()
                        .padding(20)
                        .foregroundColor(.black)
                    
                    //                    NavigationLink(destination: ImagePicker()) {
                    //                        Image(systemName: "photo")
                    //                            .font(.title)
                    //                            .foregroundColor(.white)
                    //                            .padding(20)
                    //                            .background(.black, in: Circle())
                    //                    }
                    TextField("Nome", text: $nome)
                        .padding().frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.1))
                        .cornerRadius(10)
                    TextField("Cognome", text: $cognome)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.1))
                        .cornerRadius(10)
                    TextField("Numero", text: $numero)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.1))
                        .cornerRadius(10)
                    TextField("Email", text: $email)
                        .padding().frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.1))
                        .cornerRadius(10)
                        
                    
                        Button(action: {
                            //       MARK:       DEVE ARRIVARE NELLA SCHERMATA DI PARTENZA
                            
                        }, label: {
                            Text("Crea")
                                .position(x:60,y:7)
                                .padding()
                                .frame(width: 150, height: 50)
                                .background(Color.yellow.opacity(0.1))
                                .cornerRadius(50)
                            
                        })
                        
                    }
                
                .position(x: 200,y:200)
                VStack{
                    if let data = data, let uiimage = UIImage(data: data) { Image(uiImage: uiimage)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 350)
                            .clipShape(Circle())
                            .position(x: 200, y: 550)
                        
                    }
                    Spacer()
                    PhotosPicker("photo", selection: $selectedItems, maxSelectionCount: 1, matching: .images
                    )
                    //                    .position(x:188,y:280)
                    .onChange(of: selectedItems) {
                        newValue in guard let item = selectedItems.first else {
                            return
                        }
                        item.loadTransferable(type: Data.self) { result in switch result {
                        case .success(let data): if let data = data {
                            self.data = data
                        } else{
                            print("Data is nil")
                        }
                        case.failure(let failure): fatalError("failure")
                        }
                        }
                        
                    }
                }
            }
        }
    }


struct CreaBiglietto_Previews: PreviewProvider {
    static var previews: some View {
         ContentView()
        
    }
    
}
