//
//  Biglietto.swift
//  carte
//
//  Created by Assunta Pia Clarino on 17/02/23.
//

import Foundation
import SwiftUI

extension Color {
    init(hex: String) {
        let scanner = Scanner(string: hex)
        var rgbValue: UInt64 = 0
        scanner.scanHexInt64(&rgbValue)
        
        let red = Double((rgbValue & 0xFF0000) >> 16) / 255.0
        let green = Double((rgbValue & 0x00FF00) >> 8) / 255.0
        let blue = Double(rgbValue & 0x0000FF) / 255.0
        
        self.init(red: red, green: green, blue: blue)
    }
}


//1v,2h(2v)
struct BigliettoAziendale2:View{
    var biglietto: IstanzeBigliettoAziendale
    var body: some View{
        RoundedRectangle(cornerRadius: 5)
            .frame(width: 365, height: 250)
            .foregroundColor(Color.init(hex: "FFFFFF"))
            .border(.black)
            .cornerRadius(0)
            .overlay{
                
                VStack{
                    HStack{
                        Spacer()
                        Image("profilo")
                            .resizable()
                            .frame(width: 70, height: 55)
                            .clipShape(Circle())
                        
                        
                    }
                    HStack{
                        Spacer()
                        VStack{
                            Text(biglietto.nome + " " + biglietto.cognome)
                                .bold()
                        }
                    }
                    HStack{
                        Spacer()
                        VStack{
                            Text(biglietto.numero)
                        }
                    }
                    HStack{
                        VStack{
                            Text(biglietto.azienda)
                        }
                        Spacer()
                        VStack{
                            Text(biglietto.email)
                        }
                    }
                    HStack{
                        VStack{
                            Text(biglietto.ruolo)
                        }
                        Spacer()
                        VStack{
                            Text("Ulteriori contatti")
                        }
                    }
                    HStack{
                        VStack{
                            Image("icon4")
                                .resizable()
                                .frame(width: 70, height: 55)
                                .clipShape(Rectangle())
                            
                        }
                        Spacer()
                        
                    }
                    
                }.padding()
            }
        
    }
}


//struct BigliettoAziendale2_Previews: PreviewProvider {
//    static var previews: some View {
//        BigliettoAziendale2(biglietto: IstanzeBigliettoAziendale())
//    }
//}
