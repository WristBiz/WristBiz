//
//  Test.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 19/02/23.
//

import SwiftUI

struct Test: View {
    var body: some View {
        Text("Sei dentro").foregroundColor(.black)
    }
}

struct Test_Previews: PreviewProvider {
    static var previews: some View {
        Test()
    }
}
