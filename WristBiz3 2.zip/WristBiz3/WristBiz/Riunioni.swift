//
//  Riunioni.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 17/02/23.
//

import SwiftUI
import WatchConnectivity
import ParthenoKit

struct Riunioni: View {
    @ObservedObject var viewModel: iPhoneViewModel
    @State var codice: String = "ciao"
    var scartaBiglietti: [IstanzeBigliettoAziendale] = [IstanzeBigliettoAziendale()]
    var body: some View {
        ZStack{
            Rectangle()
                .opacity(0.01)
                .background(Image("sfondo").opacity(0.3))
            VStack(alignment: .leading){
                Text("Riunioni")
                //                        .position(x:90,y:50)
                //                        .padding()
                    .font(.title)
                    .font(.system(size: 40))
                    .fontWeight(.bold)
                    .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
                Text("In questa sezione è possibile generare un codice casuale per la creazione della stanza virtuale")
//                    .padding()
//                    .position(x:200,y:-220)
                    .font(.system(size: 25))
                    .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
               
                VStack(alignment: .center){
                    Text("Il tuo codice casuale è:")
                        .padding()
                        .fontWeight(.bold)
                        .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
                        .font(.title2)
                    Text("\(codice)")
                        .padding()
                        .fontWeight(.bold)
                        .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
                        .font(.title)
                    
                    
                    Button(action: {
                        codice=generateCode()
                    }, label: {
                        Text("Genera codice")
                            .font(.title)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color(red: 0.000, green: 0.013, blue: 0.422), in: Rectangle())
                            .cornerRadius(15)
                        //                        .position(x:190,y:550)
                    })
                }
            }
            
        }.padding(15)
    }
}

struct Riunioni_Previews: PreviewProvider {
    static var previews: some View {
        Riunioni(viewModel: iPhoneViewModel())
    }
}

func generateCode() -> String {
    let code = String(format: "%04d", Int.random(in: 0...9999))
    return code
}




struct BigliettoView: View{
    @State var v: IstanzeBigliettoAziendale
    var body: some View{
        HStack{
            Text("\(v.azienda)")
            Text("\(v.ruolo)")
            Text("\(v.nome)")
            Text("\(v.cognome)")
            Text("\(v.numero)")
            Text("\(v.email)")
        }
    }
}
struct BigliettoView2: View{
    let v: IstanzeBigliettoAziendale
    var body: some View{
        HStack{
            Text("\(v.azienda)")
            Text("\(v.ruolo)")
            Text("\(v.nome)")
            Text("\(v.cognome)")
            Text("\(v.numero)")
            Text("\(v.email)")
        }
    }
}



