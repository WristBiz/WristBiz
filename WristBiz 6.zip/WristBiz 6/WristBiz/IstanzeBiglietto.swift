//
//  IstanzeBiglietto.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 14/02/23.
//

import SwiftUI

class IstanzeBiglietto: Hashable, Identifiable {
    
    var id = UUID()
    var nome: String = " "
    var cognome: String = " "
    var numero: String = " "
    var email: String = " "
    var Accettato: Bool = false
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(nome)
        hasher.combine(cognome)
        hasher.combine(numero)
        hasher.combine(email)
    }
    init(nome: String, cognome: String, numero: String, email: String, Accettato: Bool) {
        self.nome = nome
        self.cognome = cognome
        self.numero = numero
        self.email = email
        self.Accettato = Accettato
    }
     
    init() {}
    
    static func == (lhs: IstanzeBiglietto, rhs: IstanzeBiglietto) -> Bool {return true}
    
   
}
