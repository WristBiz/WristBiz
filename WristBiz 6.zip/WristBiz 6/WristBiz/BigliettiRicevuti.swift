//
//  BigliettiRicevuti.swift
//  WalletUI
//
//  Created by Ciro Pazzi on 07/02/23.
//

import SwiftUI
import SwiftUI
import WatchConnectivity
import ParthenoKit

struct BigliettiRicevuti: View {
    @ObservedObject var viewModel: iPhoneViewModel
    public var personalData: IstanzeBiglietto
    @State private var counter = 0
    @State var ScartaBiglietti: [IstanzeBiglietto] = [IstanzeBiglietto()]
    var p: ParthenoKit = ParthenoKit()
    
    var body: some View {
        VStack{
            
           Biglietto2View(viewModel: viewModel, biglietti: ScartaBiglietti)
            
        }  .onAppear {
            let timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
                ScartaBiglietti = leggiBiglietti(p: p, meetingCode: viewModel.meetingCode)
                
            }
//            RunLoop.current.add(timer, forMode: .common)
            
        }
    }
}
struct Biglietto2View: View{
    @ObservedObject var viewModel: iPhoneViewModel
    var biglietti: [IstanzeBiglietto]
    var body: some View {

        List(biglietti){
            biglietto in
                BigliettoAziendale2(biglietto: biglietto)
            Spacer()
        }
//        let biglietto: IstanzeBiglietto = IstanzeBiglietto(nome: "m", cognome: "n", numero: "o", email: "p", Accettato: false)
//        WalletRicevuti(viewModel: viewModel , biglietto: biglietto)
    }
}


struct BigliettoView: View{
    @State var v: IstanzeBiglietto
    var body: some View{
        HStack{
            Text("\(v.nome)")
            Text("\(v.cognome)")
            Text("\(v.numero)")
            Text("\(v.email)")
        }
    }
}
struct BigliettoView2: View{
    let v: IstanzeBiglietto
    var body: some View{
        HStack{
            Text("\(v.nome)")
            Text("\(v.cognome)")
            Text("\(v.numero)")
            Text("\(v.email)")
        }
    }
}

