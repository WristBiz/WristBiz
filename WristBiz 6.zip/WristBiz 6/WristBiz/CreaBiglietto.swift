//
//  CreaBiglietto.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 14/02/23.
//

import SwiftUI
import PhotosUI
var Biglietto1:IstanzeBiglietto = IstanzeBiglietto()





struct DatiPersonali: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    @State private var isShown: Bool = false
    @State private var sourceType: UIImagePickerController.SourceType = .camera
    @ObservedObject var viewModel: iPhoneViewModel
    @State var personalData = IstanzeBiglietto()
    @Binding var isPresented: Bool
    var body: some View {
        NavigationView{
            ZStack{
                Rectangle()
                    .foregroundColor(Color(hue: 0.129, saturation: 0.236, brightness: 0.979))
                    .padding(-100)
                
                VStack{
                    Text("Crea il Tuo Biglietto da Visita")
                        .font(.title)
                        .bold()
                        .padding(20)
                        .foregroundColor(.black)
                    
                    
                    TextField("Nome", text: $personalData.nome)
                        .padding().frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.1))
                        .cornerRadius(10)
                    TextField("Cognome", text: $personalData.cognome)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.1))
                        .cornerRadius(10)
                    TextField("Numero", text: $personalData.numero)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.1))
                        .cornerRadius(10)
                    TextField("Email", text: $personalData.email)
                        .padding().frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.1))
                        .cornerRadius(10)
                    
                    
                    NavigationLink(destination:
                                    BigliettoAziendale3(viewModel: viewModel, biglietto: personalData, isPresented: $isPresented)
                                   , label: {
                        Text("Crea")
                    })
                    Button(action: {Biglietto1 = personalData}, label: {Text("salva")})
                    
                    
                }
                
                .position(x: 200,y:200)
                VStack{
                    if let data = data, let uiimage = UIImage(data: data) { Image(uiImage: uiimage)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 350)
                            .clipShape(Circle())
                            .position(x: 200, y: 550)
                        
                    }
                    Spacer()
                    PhotosPicker("photo", selection: $selectedItems, maxSelectionCount: 1, matching: .images
                    )
                    //                    .position(x:188,y:280)
                    .onChange(of: selectedItems) {
                        newValue in guard let item = selectedItems.first else {
                            return
                        }
                        item.loadTransferable(type: Data.self) { result in switch result {
                        case .success(let data): if let data = data {
                            self.data = data
                        } else{
                            print("Data is nil")
                        }
                        case.failure(let failure): fatalError("failure")
                        }
                        }
                        
                    }
                }
            }
            
        }
    }
}

struct DatiAzienda: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    @State private var isShown: Bool = false
    @State private var sourceType: UIImagePickerController.SourceType = .camera
    @State var nomeAzienda = ""
    @State var Ruolo = ""
    @Binding var isPresented: Bool
    @ObservedObject var viewModel: iPhoneViewModel
    var body: some View {
        
        ZStack{
            Rectangle()
                .foregroundColor(Color(hue: 0.129, saturation: 0.236, brightness: 0.979))
                .padding(-100)
            
            VStack{
                Text("Inserisci i Dati della tua Azienda")
                    .font(.title)
                    .bold()
                    .padding(20)
                    .foregroundColor(.black)
                
                TextField("Nome Azienda", text: $nomeAzienda)
                    .padding().frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                    .cornerRadius(10)
                TextField("Ruolo", text: $Ruolo)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                    .cornerRadius(10)
                
                NavigationLink(destination: DatiPersonali(viewModel: viewModel, isPresented: $isPresented), label:{
                    Text("Avanti")
                        .position(x:60,y:7)
                        .padding()
                        .frame(width: 150, height: 50)
                        .background(Color.yellow.opacity(0.1))
                        .cornerRadius(50)
                })
                
//                NavigationLink(destination:BigliettoAziendale3(viewModel: viewModel, biglietto: personalData, isPresented: $isPresented), label: {
//                    Text("Avanti")
//                })
                
            }.position(x: 200,y:200)
            VStack{
                if let data = data, let uiimage = UIImage(data: data) { Image(uiImage: uiimage)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 350)
                        .clipShape(Circle())
                        .position(x: 200, y: 550)
                    
                }
                Spacer()
                PhotosPicker("photo", selection: $selectedItems, maxSelectionCount: 1, matching: .images
                )
                //                    .position(x:188,y:280)
                .onChange(of: selectedItems) {
                    newValue in guard let item = selectedItems.first else {
                        return
                    }
                    item.loadTransferable(type: Data.self) { result in switch result {
                    case .success(let data): if let data = data {
                        self.data = data
                    } else{
                        print("Data is nil")
                    }
                    case.failure(let failure): fatalError("failure")
                    }
                    }
                    
                }
            }
        }
    }
}


struct ImagePicker: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    var body: some View {
        VStack{
            if let data = data, let uiimage = UIImage(data: data) { Image(uiImage: uiimage)
                    .resizable()
            }
            Spacer()
            PhotosPicker("Your Photo", selection: $selectedItems, maxSelectionCount: 1, matching: .images
            )
            .onChange(of: selectedItems) {
                newValue in guard let item = selectedItems.first else {
                    return
                }
                item.loadTransferable(type: Data.self) { result in switch result {
                case .success(let data): if let data = data {
                    self.data = data
                } else{
                    print("Data is nil")
                }
                case.failure(let failure): fatalError("failure")
                }
                }
            }
        }
    }
}
