//
//  RicevutiSalvati.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 15/02/23.
//

import SwiftUI

struct RicevutiSalvati: View {
    @State private var searchText = ""
    @State var text = ""
    var body: some View {
        ZStack{
            Rectangle()
                .foregroundColor(Color(hue: 0.129, saturation: 0.236, brightness: 0.979))
                .padding(-1000)
            HStack{
                VStack {
                    Text("Salvati")
                        .padding()
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                        .font(.title)
                    Spacer()
                }
                Spacer()
            }
            VStack(){
                Spacer()
                HStack {
                    Spacer()
                    FilterView()
                    
                }.searchable(text: $text)
                
            }
        }
    }
}

struct BarraDiRicerca: View {
    @State private var searchText = ""
    var body: some View {
        VStack {
            SearchBar(text: $searchText)
            // aggiungi qui i tuoi contenuti
        }
    }
}

struct SearchBar: View {
    @Binding var text: String
    
    var body: some View {
        HStack {
            TextField("Search...", text: $text)
                .padding(7)
                .background(Color(.systemGray6))
                .cornerRadius(8)
                .padding(.horizontal, 15)
            
            Button(action: {
                self.text = ""
            }) {
                Image(systemName: "xmark.circle.fill")
                    .foregroundColor(.gray)
            }
        }
    }
}

struct FilterView: View {
    @State private var isFilterVisible = false
    @State private var selectedDate = Date()
    
    var body: some View {
        VStack {
            Button(action: {
                isFilterVisible.toggle()
            }) {
                Image(systemName: "calendar.badge.clock" ).foregroundColor(.black)
            }
            .padding()
            .sheet(isPresented: $isFilterVisible, content: {
                VStack {
                    DatePicker("Select date", selection: $selectedDate, displayedComponents: .date).foregroundColor(.black)
                        .datePickerStyle(GraphicalDatePickerStyle())
                        .padding(.vertical, 10)
                    
                    Button("Apply Filter") {
                        // Add code here to apply the filter
                        isFilterVisible.toggle()
                    }
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.black)
                    .cornerRadius(10)
                    .padding(.top, 10)
                }
                .foregroundColor(.yellow)
                .padding(.vertical, 10)
                .padding(.horizontal, 20)
                .background(Color.white.opacity(0.2))
                .cornerRadius(10)
            })
        }
    }
}


struct RicevutiSalvati_Previews: PreviewProvider {
    static var previews: some View {
        RicevutiSalvati()
    }
}

