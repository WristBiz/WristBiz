//
//  SceltaInviati.swift
//  WristBiz Watch App
//
//  Created by Ciro Pazzi on 10/02/23.
//

import SwiftUI
import WatchConnectivity

struct SceltaInviati: View {
    @ObservedObject var viewModel: WatchViewModel
    var body: some View {
        ScrollView{
            VStack(spacing: 1) {
                Text("\(viewModel.meetingCode)")
                    .font(.footnote)
                    .bold()
                    .padding()
                HStack(spacing: 1) {
                    ForEach(1...3, id: \.self) { row in
                        VStack(spacing: 1) {
                            ForEach(1...3, id: \.self) { column in
                                Button("\((column - 1) * 3 + row)") {
                                    viewModel.meetingCode.append("\((column - 1) * 3 + row)")
                                }
                            }
                        }
                    }
                    
                }
                HStack{
                    Button(action: {
                        viewModel.sendMessageToiPhone(viewModel.meetingCode)
                    }, label: {
                        Image(systemName: "checkmark")
                    }).background(Color(hue: 0.363, saturation: 0.956, brightness: 0.56)).cornerRadius(10)
                    Button(action: {
                       
                    viewModel.meetingCode.append("0")
                    }, label: {
                        Text("0")
                    }).cornerRadius(10)
                    Button(action: {
                        viewModel.meetingCode = String(viewModel.meetingCode.dropLast())
                    }, label: {
                        Image(systemName: "xmark")
                    }).background(Color(hue: 0.001, saturation: 0.997, brightness: 0.93)).cornerRadius(10)
                }
                
//            VStack {
//                Button("Clear") {
//                    self.meetingCode = ""
//                }.tint(Color(hue: 0.109, saturation: 0.602, brightness: 0.982))
//                    .padding(.horizontal, 30)
//                    .background(Color(hue: 0.109, saturation: 0.602, brightness: 0.982))
//                    .cornerRadius(20)
//                Button("Clear") {
//                    self.meetingCode = ""
//                }.tint(Color(hue: 0.109, saturation: 0.602, brightness: 0.982))
//                    .padding(.horizontal, 30)
//                    .background(Color(hue: 0.109, saturation: 0.602, brightness: 0.982))
//                    .cornerRadius(20)
//                Spacer()
//            }
            }.padding(20)
        }
    }
}
struct SceltaInviati_Previews: PreviewProvider {
    static var previews: some View {
        SceltaInviati(viewModel: WatchViewModel())
    }
}

struct Carosello: View {
    let cards = ["card1", "card2", "card3"]
    var body: some View {
        VStack{
            List{
                Spacer()
                    .listRowBackground(Color.black)
                ForEach(self.cards, id: \.self) { card in
                    Image(card)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .listRowBackground(Color.black)
                }
                
                Spacer()
                    .listRowBackground(Color.black)
                }
            .listStyle(.carousel)
            }
        }
    }
