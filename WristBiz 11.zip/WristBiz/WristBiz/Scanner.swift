//
//  Scanner.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 26/02/23.
//

import SwiftUI
import VisionKit
import Vision

struct ScannerView: UIViewControllerRepresentable {
    
    @Binding var name: String
    @Binding var surname: String
    @Binding var phoneNumber: String
    @Binding var address: String
    @Binding var email: String
    
    func makeUIViewController(context: Context) -> VNDocumentCameraViewController {
        let documentCameraViewController = VNDocumentCameraViewController()
        documentCameraViewController.delegate = context.coordinator
        return documentCameraViewController
    }
    
    func updateUIViewController(_ uiViewController: VNDocumentCameraViewController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(scannerView: self)
    }
    
    class Coordinator: NSObject, VNDocumentCameraViewControllerDelegate {
        
        var scannerView: ScannerView
        
        init(scannerView: ScannerView) {
            self.scannerView = scannerView
        }
        
        func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) {
            
            let image = scan.imageOfPage(at: 0)
            let requestHandler = VNImageRequestHandler(cgImage: image.cgImage!)
            
            let textRecognitionRequest = VNRecognizeTextRequest { (request, error) in
                if let error = error {
                    print("Error recognizing text: \(error.localizedDescription)")
                    return
                }
                
                guard let observations = request.results as? [VNRecognizedTextObservation] else {
                    print("No text recognized")
                    return
                }
                
                var name = ""
                var surname = ""
                var phoneNumber = ""
                var address = ""
                var email = ""
                
                for observation in observations {
                    guard let topCandidate = observation.topCandidates(1).first else { continue }
                    
                    if topCandidate.string.contains("Nome") {
                        if let nameCandidate = observation.topCandidates(1).first {
                            name = nameCandidate.string
                        }
                    } else if topCandidate.string.contains("Cognome") {
                        if let surnameCandidate = observation.topCandidates(1).first {
                            surname = surnameCandidate.string
                        }
                    } else if topCandidate.string.contains("Telefono") {
                        if let phoneNumberCandidate = observation.topCandidates(1).first {
                            phoneNumber = phoneNumberCandidate.string
                        }
                    } else if topCandidate.string.contains("Indirizzo") {
                        if let addressCandidate = observation.topCandidates(1).first {
                            address = addressCandidate.string
                        }
                    } else if topCandidate.string.contains("Email") {
                        if let emailCandidate = observation.topCandidates(1).first {
                            email = emailCandidate.string
                        }
                    }
                }
                
                DispatchQueue.main.async {
                    self.scannerView.name = name
                    self.scannerView.surname = surname
                    self.scannerView.phoneNumber = phoneNumber
                    self.scannerView.address = address
                    self.scannerView.email = email
                }
            }
            
            do {
                try requestHandler.perform([textRecognitionRequest])
            } catch {
                print("Error performing text recognition request: \(error.localizedDescription)")
            }
            
            controller.dismiss(animated: true, completion: nil)
        }
        
        func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) {
            controller.dismiss(animated: true, completion: nil)
        }
        
        func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFailWithError error: Error) {
            print("Error scanning document: \(error.localizedDescription)")
            controller.dismiss(animated: true, completion: nil)
        }
    }
}

struct ScannerContentView: View {
    
    @State var name = ""
    @State var surname = ""
    @State var phoneNumber = ""
    @State var address = ""
    @State var email = ""
    
    @State var showScannerView = false
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Name: \(name)")
                Text("Surname: \(surname)")
                Text("Phone number: \(phoneNumber)")
                Text("Address: \(address)")
                Text("Email: \(email)")
                
                Spacer()
                
                Button("Scan") {
                    showScannerView = true
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                .sheet(isPresented: $showScannerView) {
                    ScannerView(name: $name, surname: $surname, phoneNumber: $phoneNumber, address: $address, email: $email)
                }
            }
            .navigationTitle("Document Scanner")
        }
    }
}

struct Scanner_Previews: PreviewProvider {
    static var previews: some View {
        ScannerContentView()
    }
}
