import SwiftUI

struct Convertitore: View {
    
    @State private var image: UIImage?
    
    var body: some View {
        VStack {
            Text("Esempio di vista da convertire in immagine")
            Rectangle()
                .fill(Color.blue)
                .frame(width: 200, height: 200)
            Button(action: {
                image = self.convertToImage(view: self.getView())
            }) {
                Text("Converti in immagine")
            }
            if let img = image {
                Image(uiImage: img)
                    .resizable()
                    .scaledToFit()
            }
        }
    }
    
    func getView() -> some View {
        return VStack {
            Text("Vista convertita in immagine")
            Rectangle()
                .fill(Color.red)
                .frame(width: 100, height: 100)
        }
    }
    
    func convertToImage<Content: View>(view: Content) -> UIImage? {
        let controller = UIHostingController(rootView: view)
        let viewImage = controller.view ?? UIImage(systemName: "photo")
        return viewImage as! UIImage
    }
}

struct ViewToImage: UIViewRepresentable {
    func makeCoordinator() -> Coordinator {
        Coordinator()
    }
    
    
    let view: UIView
    
    init(view: UIView) {
        self.view = view
    }
    
    func makeUIView(context: Context) -> UIView {
        return view
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {}
    
    
    class Coordinator: NSObject {}
    
    func makeImage() -> UIImage? {
        let renderer = UIGraphicsImageRenderer(bounds: view.bounds)
        let image = renderer.image { ctx in
            view.layer.render(in: ctx.cgContext)
        }
        return image
    }
}
struct Convertitore_Previews: PreviewProvider {
    static var previews: some View {
        Convertitore()
    }
}
