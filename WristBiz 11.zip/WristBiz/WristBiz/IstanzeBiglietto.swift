//
//  IstanzeBiglietto.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 14/02/23.
//

import SwiftUI

class IstanzeBiglietto: Hashable, Identifiable {
    
    var id = UUID()
    var nome: String = " "
    var cognome: String = " "
    var numero: String = " "
    var email: String = " "
    var Accettato: Bool = false
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(nome)
        hasher.combine(cognome)
        hasher.combine(numero)
        hasher.combine(email)
    }
    init(nome: String, cognome: String, numero: String, email: String, Accettato: Bool) {
        self.nome = nome
        self.cognome = cognome
        self.numero = numero
        self.email = email
        self.Accettato = Accettato
    }
     
    init() {}
    
    static func == (lhs: IstanzeBiglietto, rhs: IstanzeBiglietto) -> Bool {return true}
    
   
}

class IstanzeBigliettoAziendale: Hashable, Identifiable {
    
    var id = UUID()
    var azienda: String = " "
    var ruolo: String = " "
    var nome: String = " "
    var cognome: String = " "
    var numero: String = " "
    var email: String = " "

    
    func hash(into hasher: inout Hasher) {
        hasher.combine(azienda)
        hasher.combine(ruolo)

    }
    init(azienda: String, ruolo: String, nome: String, cognome: String, numero: String, email: String) {
        self.azienda = azienda
        self.ruolo = ruolo
        self.nome = nome
        self.cognome = cognome
        self.numero = numero
        self.email = email
    }
     
    init() {}
    
    static func == (lhs: IstanzeBigliettoAziendale, rhs: IstanzeBigliettoAziendale) -> Bool {return true}
    
   
}
