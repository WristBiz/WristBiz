//
//  WristBizApp.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 10/02/23.
//

import SwiftUI

@main
struct WristBizApp: App {
    var body: some Scene {
        WindowGroup {
            MyTabView(isPresented: true)
        }
    }
}
