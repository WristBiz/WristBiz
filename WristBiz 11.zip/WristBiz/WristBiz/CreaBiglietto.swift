//
//  CreaBiglietto.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 14/02/23.
//

import SwiftUI
import PhotosUI

struct CreaBiglietto: View {
    @State var Contatore: Int = 0
    @ObservedObject var viewModel: iPhoneViewModel
    @Binding var isPresented: Bool
    var body: some View {
        ZStack{
            Rectangle()
                .foregroundColor(Color(hue: 0.129, saturation: 0.236, brightness: 0.979))
                .padding(-100)
            VStack
            {
                Button("Biglieto Personale", action: {
                    Contatore = 1
                })
                Button("Biglieto Aziendale", action: {
                    Contatore = 2
                })
            }
            if Contatore == 1
            {
                DatiPersonali(viewModel: viewModel, isPresented: $isPresented)
            } else if Contatore == 2 {
                DatiAzienda(isPresented: $isPresented, viewModel: viewModel)
            }
        }
        }
    }


//struct CreaBiglietto_Previews: PreviewProvider {
//    static var previews: some View {
//        CreaBiglietto()
//    }
//}


struct DatiPersonali: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    @State private var isShown: Bool = false
    @State private var sourceType: UIImagePickerController.SourceType = .camera
    @ObservedObject var viewModel: iPhoneViewModel
    @Binding var isPresented: Bool
    
    @State var personalData = IstanzeBiglietto(nome: "", cognome: "", numero: "", email: "", Accettato: true)

//    @State var biglietto = IstanzeBiglietto()
    
    var body: some View {
        NavigationView{
        ZStack{
            Rectangle()
                .foregroundColor(.white)
                .padding(-100)
            VStack{
                Text("Crea il Tuo Biglietto da Visita")
                    .font(.title)
                    .bold()
                    .padding(20)
                    .foregroundColor(.black)
              
                
                TextField("Nome", text: $personalData.nome)
                    .padding().frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                    .cornerRadius(10)
                TextField("Cognome", text: $personalData.cognome)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                    .cornerRadius(10)
                TextField("Numero", text: $personalData.numero)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                    .cornerRadius(10)
                TextField("Email", text: $personalData.email)
                    .padding().frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                    .cornerRadius(10)
                
        
                
                NavigationLink(destination: BigliettoPersonale3(viewModel: viewModel, biglietto: personalData, isPresented: $isPresented), label: {
                    Text("Crea")
                })
                
            }
            
            .position(x: 200,y:200)
            VStack{
                if let data = data, let uiimage = UIImage(data: data) { Image(uiImage: uiimage)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 350)
                        .clipShape(Circle())
                        .position(x: 200, y: 550)
                    
                }
                Spacer()
                PhotosPicker("photo", selection: $selectedItems, maxSelectionCount: 1, matching: .images
                )
                //                    .position(x:188,y:280)
                .onChange(of: selectedItems) {
                    newValue in guard let item = selectedItems.first else {
                        return
                    }
                    item.loadTransferable(type: Data.self) { result in switch result {
                    case .success(let data): if let data = data {
                        self.data = data
                    } else{
                        print("Data is nil")
                    }
                    case.failure(let failure): fatalError("failure")
                    }
                    }
                    
                }
            }
            }
        }
    }
}
struct DatiAzienda: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    @State private var isShown: Bool = false
    @State private var sourceType: UIImagePickerController.SourceType = .camera
    @State var nomeAzienda = ""
    @State var Ruolo = ""
    @Binding var isPresented: Bool
    @ObservedObject var viewModel: iPhoneViewModel
    
    @State var personalData = IstanzeBigliettoAziendale(azienda: "", ruolo: "", nome: "", cognome: "", numero: "", email: "")
    
    var body: some View {
        NavigationView{
        ZStack{
            
            VStack{
                Spacer()
                Text("Inserisci i Dati della tua Azienda")
                    .font(.title)
                    .bold()
                    .padding(20)
                    .foregroundColor(.black)
                
                TextField("Nome Azienda", text: $nomeAzienda)
                    .padding().frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                    .cornerRadius(10)
                TextField("Ruolo", text: $Ruolo)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                TextField("Nome", text: $personalData.nome)
                    .padding().frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                    .cornerRadius(10)
                TextField("Cognome", text: $personalData.cognome)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                    .cornerRadius(10)
                TextField("Numero", text: $personalData.numero)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                    .cornerRadius(10)
                TextField("Email", text: $personalData.email)
                    .padding().frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                    .cornerRadius(10)
                
                NavigationLink(destination: BigliettoAziendale(personalData: personalData), label:{
                    Text("Avanti")
                        .position(x:60,y:7)
                        .padding()
                        .frame(width: 150, height: 50)
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(50)
                })
                NavigationLink(destination: BigliettoAziendale3(viewModel: viewModel, biglietto: personalData, isPresented: $isPresented), label: {
                    Text("Avanti")
                })
                
            }.position(x: 200,y:200)
            VStack{
                if let data = data, let uiimage = UIImage(data: data) { Image(uiImage: uiimage)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 350)
                        .clipShape(Circle())
                        .position(x: 200, y: 550)
                    
                }
                Spacer()
                PhotosPicker("photo", selection: $selectedItems, maxSelectionCount: 1, matching: .images
                )
                //                    .position(x:188,y:280)
                .onChange(of: selectedItems) {
                    newValue in guard let item = selectedItems.first else {
                        return
                    }
                    item.loadTransferable(type: Data.self) { result in switch result {
                    case .success(let data): if let data = data {
                        self.data = data
                    } else{
                        print("Data is nil")
                    }
                    case.failure(let failure): fatalError("failure")
                    }
                    }
                    
                }
            }
            }
        }
    }
}

struct BigliettoPersonale: View {
    var personalData: IstanzeBiglietto
    
    var body: some View {
        
        ZStack{
            VStack{
                Text("Nome: \(personalData.nome)")
                Text("Cognome: \(personalData.cognome)")
                Text("Numero: \(personalData.numero)")
                Text("Email: \(personalData.email)")
            }
            
        }
    }
}

struct BigliettoAziendale: View {
    var personalData: IstanzeBigliettoAziendale
    
    var body: some View {
        
        ZStack{
            VStack{
                Text("Nome: \(personalData.nome)")
                Text("Cognome: \(personalData.cognome)")
                Text("Numero: \(personalData.numero)")
                Text("Email: \(personalData.email)")
                Text("Azienda: \(personalData.azienda)")
                Text("Ruolo: \(personalData.ruolo)")
            }
            
        }
    }
}

struct BigliettoAziendale3:View{
    @ObservedObject var viewModel: iPhoneViewModel
    var biglietto: IstanzeBigliettoAziendale
    @Binding var isPresented: Bool
//    @Binding var selectedItems: [PhotosPickerItem]
    
    var body: some View{
        RoundedRectangle(cornerRadius: 25)
            .frame(width: 365, height: 250)
            .foregroundColor(Color.init(hex: "FFFFFF"))
            .border(.black)
            .cornerRadius(0)
            .overlay{
                
                VStack{
                    HStack{
                        Spacer()
                        Image("profilo")
                            .resizable()
                            .frame(width: 70, height: 55)
                            .clipShape(Circle())
                        
                        
                    }
                    HStack{
                        Spacer()
                        VStack{
                            Text(biglietto.nome + " " + biglietto.cognome)
                                .bold()
                        }
                    }
                    HStack{
                        Spacer()
                        VStack{
                            Text(biglietto.numero)
                        }
                    }
                    HStack{
                        VStack{
                            Text("Azienda")
                        }
                        Spacer()
                        VStack{
                            Text(biglietto.email)
                        }
                    }
                    HStack{
                        VStack{
                            Text("ruolo")
                        }
                        Spacer()
                        VStack{
                            Text("Ulteriori contatti")
                        }
                    }
                    HStack{
                        VStack{
//                            Image("icon4")
                            Image("Biglietto")
                                .resizable()
                                .frame(width: 70, height: 55)
                                .clipShape(Rectangle())
                            
                        }
                        Spacer()
                        
                    }
                    
                    
                    
                }.padding()
            }
            .navigationBarItems(trailing: Button(action: {
                isPresented = false
            }, label: {
                Text("Fine")
            }))
        
        
        
    }
}

struct BigliettoPersonale3:View{
    @ObservedObject var viewModel: iPhoneViewModel
    var biglietto: IstanzeBiglietto
    @Binding var isPresented: Bool
//    @Binding var selectedItems: [PhotosPickerItem]
    
    
    var body: some View{
        RoundedRectangle(cornerRadius: 25)
            .frame(width: 365, height: 250)
            .foregroundColor(Color.init(hex: "FFFFFF"))
            .border(.black)
            .cornerRadius(0)
            .overlay{
                
                VStack{
                    HStack{
                        Spacer()
                        Image("profilo")
                            .resizable()
                            .frame(width: 70, height: 55)
                            .clipShape(Circle())
                        
                        
                    }
                    HStack{
                        Spacer()
                        VStack{
                            Text(biglietto.nome + " " + biglietto.cognome)
                                .bold()
                        }
                    }
                    HStack{
                        Spacer()
                        VStack{
                            Text(biglietto.numero)
                        }
                    }
                    HStack{
                        VStack{
                            Text("Azienda")
                        }
                        Spacer()
                        VStack{
                            Text(biglietto.email)
                        }
                    }
                    HStack{
                        VStack{
                            Text("ruolo")
                        }
                        Spacer()
                        VStack{
                            Text("Ulteriori contatti")
                        }
                    }
                    HStack{
                        VStack{
                            Image("Biglietto")
                                .resizable()
                                .frame(width: 70, height: 55)
                                .clipShape(Rectangle())
                            
                        }
                        Spacer()
                        
                    }
                    
                    
                    
                }.padding()
            }
            .navigationBarItems(trailing: Button(action: {
                isPresented = false
            }, label: {
                Text("Fine")
            }))
        
        
        
    }
}

struct ImagePicker: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    var body: some View {
        VStack{
            if let data = data, let uiimage = UIImage(data: data) { Image(uiImage: uiimage)
                    .resizable()
            }
            Spacer()
            PhotosPicker("Your Photo", selection: $selectedItems, maxSelectionCount: 1, matching: .images
            )
            .onChange(of: selectedItems) {
                newValue in guard let item = selectedItems.first else {
                    return
                }
                item.loadTransferable(type: Data.self) { result in switch result {
                case .success(let data): if let data = data {
                    self.data = data
                } else{
                    print("Data is nil")
                }
                case.failure(let failure): fatalError("failure")
                }
                }
            }
        }
    }
}
