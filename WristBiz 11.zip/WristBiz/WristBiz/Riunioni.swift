//
//  Riunioni.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 17/02/23.
//

import SwiftUI
import WatchConnectivity
import ParthenoKit

struct Riunioni: View {
    @ObservedObject var viewModel: iPhoneViewModel
    @State var codice: String = "ciao"
    var scartaBiglietti: [IstanzeBiglietto] = [IstanzeBiglietto()]
    var body: some View {
        ZStack{
            VStack{
                HStack{
                    Text("Riunioni")
                        .padding()
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                        .font(.title)
                    Spacer()
                }
                Spacer()
            }
            Text("Riunione Attuale: \(viewModel.meetingCode)")
                .padding()
                .fontWeight(.regular)
                .foregroundColor(.black)
                .font(.title2).position(x:100,y:60)
            
            Text("RiunioniPrecendenti:")
                .padding()
                .fontWeight(.regular)
                .foregroundColor(.black)
                .font(.title3).position(x:110,y:90)
            Text("Il tuo codice casuale è: \(codice)").position(x:130,y:110).foregroundColor(.black)
            Button(action: {
                codice=generateCode()
            }, label: {
                Image(systemName: "arrow.clockwise")
                    .font(.title)
                    .foregroundColor(.white)
                    .padding()
                    .background(.black, in: Circle()).position(x:300,y:120)
            })
            Scrivi(meetingCode: "12345")
            }
        
        }
    }

struct Riunioni_Previews: PreviewProvider {
    static var previews: some View {
        Riunioni(viewModel: iPhoneViewModel())
    }
}

func generateCode() -> String {
    let code = String(format: "%04d", Int.random(in: 0...9999))
    return code
}


//struct Leggi: View{
//    var p: ParthenoKit = ParthenoKit()
//    @State var meetingCode: String
//    var body: some View{
//        var scartaBiglietti: [IstanzeBiglietto] = [IstanzeBiglietto()]
//        var biglietto: IstanzeBiglietto = IstanzeBiglietto()
//        Text("ciao")
//        scartaBiglietti = leggiBiglietti(p: p, meetingCode: meetingCode)
//
//
//        }
//
//    }

struct Scrivi: View {
    @State private var counter = 0
    var p: ParthenoKit = ParthenoKit()
    @State var meetingCode: String
    var body: some View {
        var ScartaBiglietti: [IstanzeBiglietto] = [IstanzeBiglietto()]
        VStack {
            Text("Counter: \(counter)")
                .padding()
            Spacer()
        }
        .onAppear {
            // Richiama la funzione "updateCounter" ogni 0.5 secondi
           let timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
               ScartaBiglietti = leggiBiglietti(p: p, meetingCode: meetingCode)

            }

            // Assicurati di fermare il timer quando la vista scompare
            // per evitare memory leaks
            RunLoop.current.add(timer, forMode: .common)
        }
        
        NavigationView{
            List(ScartaBiglietti){
                biglietto in
                NavigationLink(destination: BigliettoView(v: biglietto))
                {
                    BigliettoView2(v: biglietto)
                }
            }
        }
        
    }
    

}

struct BigliettoView: View{
    @State var v: IstanzeBiglietto
    var body: some View{
        HStack{
            Text("\(v.nome)")
            Text("\(v.cognome)")
            Text("\(v.numero)")
            Text("\(v.email)")
        }
    }
}
struct BigliettoView2: View{
    let v: IstanzeBiglietto
    var body: some View{
        HStack{
            Text("\(v.nome)")
            Text("\(v.cognome)")
            Text("\(v.numero)")
            Text("\(v.email)")
        }
    }
}



