//
//  Wallet2.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 24/02/23.
//
import SwiftUI
import PhotosUI
import Photos
import Foundation
import WatchConnectivity

struct Wallet2: View {
    var tipoBiglietto: [String] = ["Personale", "Aziendale", "Scanner"]
    let personale: String = "Personale"
    let aziendale: String = "Aziendale"
    @State var selectedBiglietto = "Personale"
    @Binding var isPresented: Bool
    @ObservedObject var viewModel: iPhoneViewModel

    var body: some View {
        ZStack{
            VStack {
                Picker("hhhhh", selection: $selectedBiglietto) {
                    ForEach(tipoBiglietto, id:\.hashValue) {
//                        selectedBiglietto = id.hashValue
                        Text($0).tag($0)
                    }
                    
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding()
                
                if selectedBiglietto == "Personale"
                {
                    DatiPersonali(viewModel: viewModel, isPresented: $isPresented)
                }
                else if selectedBiglietto == "Aziendale"
                {
                    DatiAzienda(isPresented: $isPresented, viewModel: viewModel)
                }
                else if selectedBiglietto == "Scanner"
                {
                    ScannerContentView()
                }
            }
        }
    }
}
//
//struct Wallet3_Previews: PreviewProvider {
//    static var previews: some View {
//        Wallet2()
//    }
//}
