//
//  Carosello.swift
//  WristBiz Watch App
//
//  Created by Ciro Pazzi on 10/02/23.
//

import SwiftUI

struct Carosello: View {
    let cards = ["card1", "card2", "card3"]
    var body: some View {
        VStack{
            List{
                Spacer()
                    .listRowBackground(Color.black)
                ForEach(self.cards, id: \.self) { card in
                    Image(card)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .listRowBackground(Color.black)
                }
                
                Spacer()
                    .listRowBackground(Color.black)
                }
            .listStyle(.carousel)
            }
        }
    }

struct Carosello_Previews: PreviewProvider {
    static var previews: some View {
        Carosello()
    }
}
