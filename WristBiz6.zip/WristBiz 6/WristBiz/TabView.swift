//
//  TabView.swift
//  carte
//
//  Created by Assunta Pia Clarino on 16/02/23.
//

import Foundation
import SwiftUI
import PhotosUI
struct MyTabView: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    @State var personalData = IstanzeBiglietto(nome: "", cognome: "", numero: "", email: "", Accettato: true)
    @State private var selectedTab = 0
    @StateObject var viewModel = iPhoneViewModel()
    var body: some View {
                    
                    TabView(selection: $selectedTab){
                    NavigationStack {
                        Color.yellow
                            .opacity(0.25)
                            .edgesIgnoringSafeArea(.all)
                            .overlay(
                                RicevutiSalvati()
                            )
                    }
                    .tabItem {
                        Text("Salvati")
                        Image(systemName: "folder.badge.person.crop")
                        
                            .padding()
                    }
                    .foregroundColor(.black)
                    .tag(0)
                    
                    Color.yellow
                        .opacity(0.25)
                        .edgesIgnoringSafeArea(.all)
                        .overlay(
                            BigliettiRicevuti(viewModel: viewModel, personalData: personalData)
                        )
                        .tabItem {
                            Text("Ricevuti")
                            Image(systemName: "tray.and.arrow.down")
                                .padding()
                        }
                        .tag(1)
                    
                    Color.yellow
                        .opacity(0.25)
                        .edgesIgnoringSafeArea(.all)
                        .overlay(
                            //                            Text("tab3")
                            Wallet(viewModel: viewModel)
                            
                        )
                        .tabItem {
                            Text("Miei")
                            Image(systemName: "shared.with.you")
                                .padding()
                        }
                        .tag(2)
                        
                    Color.yellow
                        .opacity(0.25)
                        .edgesIgnoringSafeArea(.all)
                        .overlay(
                                //                            Text("tab3")
                            Riunioni()
                                
                            )
                            .tabItem {
                                Text("Riunioni")
                                Image(systemName: "list.number")
                                    .padding()
                            }
                            .tag(3)
                }
                .gesture(DragGesture()
                            .onEnded({ (value) in
                                if value.translation.width > 0 {
                                    selectedTab = max(selectedTab - 1, 0)
                                } else {
                                    selectedTab = min(selectedTab + 1, 2)
                                }
                            }))
                .accentColor(.black)
                .toolbar(.visible, for: .tabBar)
                .toolbarBackground(Color.black, for: .tabBar)
                .background(Color.black)
            }
        }
struct TabView_Previews: PreviewProvider {
    static var previews: some View {
        MyTabView()
    }
}

