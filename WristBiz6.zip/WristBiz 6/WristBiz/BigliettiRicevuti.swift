//
//  BigliettiRicevuti.swift
//  WalletUI
//
//  Created by Ciro Pazzi on 07/02/23.
//

import SwiftUI
import SwiftUI
import WatchConnectivity
import ParthenoKit

struct BigliettiRicevuti: View {
    @ObservedObject var viewModel: iPhoneViewModel
    public var personalData: IstanzeBiglietto
    @State private var counter = 0
    @State var ScartaBiglietti: [IstanzeBiglietto] = [IstanzeBiglietto()]
    var p: ParthenoKit = ParthenoKit()
    
    var body: some View {
        HStack{
            Text("Riunione Attuale: \(viewModel.meetingCode)")
                .padding()
                .fontWeight(.regular)
                .foregroundColor(.black)
                .font(.title2).position(x:100,y:60)
        }
//        VStack {
//            Text("Counter: \(counter)")
//                .padding()
//            Spacer()
//        }
//        .onAppear {
//            let timer = Timer.scheduledTimer(withTimeInterval: 10, repeats: true) { _ in
//                ScartaBiglietti = leggiBiglietti(p: p, meetingCode: viewModel.meetingCode)
//            }
//            RunLoop.current.add(timer, forMode: .common)
//        }
        VStack{
            
            Button(action: {
                ScartaBiglietti = leggiBiglietti(p: p, meetingCode: viewModel.meetingCode)
                print("numero 3:\(ScartaBiglietti[1].nome)")
            })
            {
                Text("Leggi")
                    .padding(10)
                    .foregroundColor(.white)
            }.background(Color.black)
            
            Biglietto2View(viewModel: viewModel, biglietti: ScartaBiglietti)
        }
        
    }
}

struct Biglietto2View: View{
    @ObservedObject var viewModel: iPhoneViewModel
    var biglietti: [IstanzeBiglietto]
    var body: some View {
//        NavigationView{
//            List(biglietti){
//            biglietto in
////                Text(biglietto.nome)
////                print("numero 2: \(biglietto.nome)")
//                NavigationLink(destination: BigliettoView(v: biglietto)){
//                    BigliettoView2(v: biglietto)
//                }
//            }
//        }.navigationBarTitle(Text("Biglietti"))
//
//        List(biglietti){
//            biglietto in
//                BigliettoAziendale2(biglietto: biglietto)
//            Spacer()
//        }
        let biglietto: IstanzeBiglietto = IstanzeBiglietto(nome: "m", cognome: "n", numero: "o", email: "p", Accettato: false)
        WalletRicevuti(viewModel: viewModel , biglietto: biglietto)
    }
}


struct BigliettoView: View{
    @State var v: IstanzeBiglietto
    var body: some View{
        HStack{
            Text("\(v.nome)")
            Text("\(v.cognome)")
            Text("\(v.numero)")
            Text("\(v.email)")
        }
    }
}
struct BigliettoView2: View{
    let v: IstanzeBiglietto
    var body: some View{
        HStack{
            Text("\(v.nome)")
            Text("\(v.cognome)")
            Text("\(v.numero)")
            Text("\(v.email)")
        }
    }
}

