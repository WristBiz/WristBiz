//
//  Riunioni.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 17/02/23.
//

import SwiftUI
import WatchConnectivity
import ParthenoKit

struct Riunioni: View {
//    @ObservedObject var viewModel: iPhoneViewModel
    @State var codice: String = "ciao"
    var scartaBiglietti: [IstanzeBiglietto] = [IstanzeBiglietto()]
    var body: some View {
        ZStack{
            Rectangle()
                .foregroundColor(Color(hue: 0.129, saturation: 0.236, brightness: 0.979))
                .padding(-1000)
            VStack{
                HStack{
                    Text("Riunioni")
                        .padding()
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                        .font(.title)
                    Spacer()
                }
                Spacer()
            }
          
            Text("RiunioniPrecendenti:")
                .padding()
                .fontWeight(.regular)
                .foregroundColor(.black)
                .font(.title3).position(x:110,y:90)
            Text("Il tuo codice casuale è: \(codice)").position(x:130,y:110).foregroundColor(.black)
            Button(action: {
                codice=generateCode()
            }, label: {
                Image(systemName: "arrow.clockwise")
                    .font(.title)
                    .foregroundColor(.white)
                    .padding()
                    .background(.black, in: Circle()).position(x:300,y:120)
            })
//            Scrivi(meetingCode: "12345")
            }
        
        }
    }

//struct Riunioni_Previews: PreviewProvider {
//    static var previews: some View {
//        Riunioni(viewModel: iPhoneViewModel())
//    }
//}

func generateCode() -> String {
    let code = String(format: "%04d", Int.random(in: 0...9999))
    return code
}


//struct Leggi: View{
//    var p: ParthenoKit = ParthenoKit()
//    @State var meetingCode: String
//    var body: some View{
//        var scartaBiglietti: [IstanzeBiglietto] = [IstanzeBiglietto()]
//        var biglietto: IstanzeBiglietto = IstanzeBiglietto()
//        Text("ciao")
//        scartaBiglietti = leggiBiglietti(p: p, meetingCode: meetingCode)
//
//
//        }
//
//    }







