//
//  Wallet2.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 10/02/23.
//

import SwiftUI

struct Wallet2: View {
    var cards: [String] = ["B1", "B2", "B3"]
    @State private var selectedCard = 0

    var body: some View {
        VStack {
            Picker(selection: $selectedCard, label: Text("")) {
                ForEach(0 ..< cards.count) {
                    Text(self.cards[$0]).tag($0)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding()
            
            Image("Biglietto\(selectedCard + 1)")
                .resizable()
                .frame(width: 300, height: 200)
                .cornerRadius(20)

                Spacer()

                VStack(alignment: .trailing) {
                    Text("Expires")
                        .bold()
                        .font(.headline)
                    Text("12/24")
                        .font(.body)
                }
            }
            .padding()
        }
    }
struct Wallet2_Previews: PreviewProvider {
    static var previews: some View {
        Wallet2()
    }
}
