//
//  FilterView.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 17/02/23.
//

import SwiftUI

struct FilterView: View {
    @State private var isFilterVisible = false
    @State private var nameFilter = ""
    @State private var surnameFilter = ""
    @State private var roleFilter = ""
    @State private var companyFilter = ""
    
    var body: some View {
        VStack {
            Button(action: {
                isFilterVisible.toggle()
            }) {
                Image(systemName: "slider.horizontal.3").foregroundColor(.black)
            }
            .padding()
            .sheet(isPresented: $isFilterVisible, content: {
                VStack {
                    TextField("Name", text: $nameFilter)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    TextField("Surname", text: $surnameFilter)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    TextField("Role", text: $roleFilter)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    TextField("Company", text: $companyFilter)
                        .textFieldStyle(RoundedBorderTextFieldStyle())

                    Button("Apply Filter") {
                        // Add code here to apply the filter
                        isFilterVisible.toggle()
                    }
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.black)
                    .cornerRadius(10)
                    .padding(.top, 10)
                }
                .padding(.vertical, 10)
                .padding(.horizontal, 20)
                .background(Color(hue: 0.129, saturation: 0.236, brightness: 0.979).opacity(0.2))
                .cornerRadius(10)
            })
        }
    }
}

struct FilterView_Previews: PreviewProvider {
    static var previews: some View {
        FilterView()
    }
}
