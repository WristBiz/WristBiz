//
//  CreaBiglietto.swift
//  WalletUI
//
//  Created by Ciro Pazzi on 07/02/23.
//

import SwiftUI
import PhotosUI

struct DatiPersonali: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    @State private var isShown: Bool = false
    @State private var sourceType: UIImagePickerController.SourceType = .camera
    
    @State var personalData = IstanzeBiglietto(nome: "", cognome: "", numero: "", email: "", Accettato: true)

//    @State var biglietto = IstanzeBiglietto()
    
    var body: some View {
        
        ZStack{
            Rectangle()
                .foregroundColor(Color(hue: 0.129, saturation: 0.236, brightness: 0.979))
                .padding(-100)
           
            VStack{
                Text("Crea il Tuo Biglietto da Visita")
                    .font(.title)
                    .bold()
                    .padding(20)
                    .foregroundColor(.black)
              
                
                TextField("Nome", text: $personalData.nome)
                    .padding().frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                    .cornerRadius(10)
                TextField("Cognome", text: $personalData.cognome)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                    .cornerRadius(10)
                TextField("Numero", text: $personalData.numero)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                    .cornerRadius(10)
                TextField("Email", text: $personalData.email)
                    .padding().frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.1))
                    .cornerRadius(10)
                
        
                
                NavigationLink(destination: BigliettoPersonale(personalData: personalData), label: {
                    Text("Crea")
                })
                
            }
            
            .position(x: 200,y:200)
            VStack{
                if let data = data, let uiimage = UIImage(data: data) { Image(uiImage: uiimage)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 350)
                        .clipShape(Circle())
                        .position(x: 200, y: 550)
                    
                }
                Spacer()
                PhotosPicker("photo", selection: $selectedItems, maxSelectionCount: 1, matching: .images
                )
                //                    .position(x:188,y:280)
                .onChange(of: selectedItems) {
                    newValue in guard let item = selectedItems.first else {
                        return
                    }
                    item.loadTransferable(type: Data.self) { result in switch result {
                    case .success(let data): if let data = data {
                        self.data = data
                    } else{
                        print("Data is nil")
                    }
                    case.failure(let failure): fatalError("failure")
                    }
                    }
                    
                }
            }
        }
    }
}


struct DatiPersonali_Previews: PreviewProvider {
    static var previews: some View {
        DatiPersonali()
        
    }
    
}
