//
//  Wallet3.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 11/02/23.
//

import SwiftUI
import WatchConnectivity

struct Wallet3: View {
    var cards: [String] = ["Visa", "Mastercard", "American Express"]
    @ObservedObject var viewModel = iPhoneViewModel()
    @State var count: Int = 1
    @State var Count: Int = 0
    @State var expandCards: Bool = false
    @State private var selectedCard = 0
    @State private var isCardSelected = true
    
    var body: some View {
            ScrollView {
                ZStack{
                    Rectangle()
                        .foregroundColor(Color(hue: 0.129, saturation: 0.236, brightness: 0.979))
                        .padding(-1000)
                    VStack {
                        HStack (spacing:50){
                            Text("Card Wallet")
                                .font(.title)
                                .fontWeight(.bold)
                            
                            NavigationLink(destination: CreaBiglietto(), label:{
                                Text("+")
                                    .font(.title)
                                    .foregroundColor(.white)
                                    .padding(20)
                                    .background(Color(hue: 0.28, saturation: 0.948, brightness: 0.856), in: Circle())
                                    
                            })
                        }
                        
                        Spacer()
                        VStack(spacing: 20) {
                            ForEach(0 ..< cards.count) { cardIndex in
                                Button(action: {
                                    self.selectedCard = cardIndex
                                    self.isCardSelected = true
                                    //count per il watch
                                    count = cardIndex
                                    self.viewModel.sendMessageToWatch(self.count)
                                    
                                }) {
                                    Image("Biglietto\(cardIndex + 1)")
                                        .resizable()
                                        .frame(width: 300, height: 200)
                                        .cornerRadius(20)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 20)
                                                .stroke(cardIndex == selectedCard && isCardSelected ? Color.orange : Color.clear, lineWidth: 4)
                                                .animation(.default)
                                        )
                                        .opacity(isCardSelected ? 1 : 0)
                                        .animation(.default)
                                }
                            }
                        }
                    }
                }
                .padding()
                
            }
        }
    }

class iPhoneViewModel: NSObject, ObservableObject, WCSessionDelegate {
  @Published var receivedMessage: Int = 0

  private let session = WCSession.default

  func sendMessageToWatch(_ message: Int) {
    session.sendMessage(["message": message], replyHandler: nil) { (error) in
      print(error.localizedDescription)
    }
  }

  override init() {
    super.init()

    if WCSession.isSupported() {
      session.delegate = self
      session.activate()
    }
  }

  func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
    // Implementazione obbligatoria
  }

  func sessionDidBecomeInactive(_ session: WCSession) {
    // Implementazione opzionale
  }

  func sessionDidDeactivate(_ session: WCSession) {
    // Implementazione opzionale
  }

  func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
    if let message = message["message"] as? Int {
      receivedMessage = message
    }
  }
}

struct iPhoneContentView: View {
//  @ObservedObject var viewModel = iPhoneViewModel()
//  @State var count: Int = 1
  var body: some View {
//    VStack {
//      Button(action: {
Text("Hello")
//      self.viewModel.sendMessageToWatch(self.count)
//      }) {
//        Text("Send message to watch: \(count)")
//      }
    }
  }



struct Wallet3_Previews: PreviewProvider {
    static var previews: some View {
        Wallet3()
    }
}
