//
//  CreaBiglietto.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 14/02/23.
//

import SwiftUI

struct CreaBiglietto: View {
    @State var Contatore: Int = 0
    var body: some View {
        ZStack{
            
            Rectangle()
                .foregroundColor(Color(hue: 0.129, saturation: 0.236, brightness: 0.979))
                .padding(-100)
            VStack
            {
                Button("Biglieto Personale", action: {
                    Contatore = 1
                })
                Button("Biglieto Aziendale", action: {
                    Contatore = 2
                })
            }
            if Contatore == 1
            {
                DatiPersonali()
            } else if Contatore == 2 {
                DatiAzienda()
            }
        }
        }
    }


struct CreaBiglietto_Previews: PreviewProvider {
    static var previews: some View {
        CreaBiglietto()
    }
}
