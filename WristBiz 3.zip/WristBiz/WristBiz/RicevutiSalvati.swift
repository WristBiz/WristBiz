//
//  RicevutiSalvati.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 15/02/23.
//

import SwiftUI

struct RicevutiSalvati: View {
    @State private var searchText = ""
    @State var text = ""
    var body: some View {
        ZStack{
            
            Rectangle()
                .foregroundColor(Color(hue: 0.129, saturation: 0.236, brightness: 0.979))
                .padding(-1000)
            Text("Salvati")
                .padding()
                .fontWeight(.bold)
                .foregroundColor(.black)
                .font(.title)
                .position(x: 56, y: 30)
            Group{
                TextField("Search...", text: $text)
                    .padding(7)
                    .foregroundColor(.gray)
                    .background(Color.gray.opacity(0.3))
                    .cornerRadius(8)
                    .padding(.horizontal, 15)
            }.position(x:190, y:70)
            
            Button(action: {
                self.text = ""
            }) {
                Image(systemName: "xmark.circle.fill")
                    .foregroundColor(.black)
            }.position(x:340, y:70)
            FilterView().position(x:340, y:105)
            
        }
            
        }
    }

struct RicevutiSalvati_Previews: PreviewProvider {
    static var previews: some View {
        RicevutiSalvati()
    }
}

