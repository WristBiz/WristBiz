//
//  BarraDiRicerca.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 16/02/23.
//

import SwiftUI

struct BarraDiRicerca: View {
    @State private var searchText = ""
    var body: some View {
        VStack {
            SearchBar(text: $searchText)
            // aggiungi qui i tuoi contenuti
        }
    }
}

struct SearchBar: View {
    @Binding var text: String
    
    var body: some View {
        HStack {
            TextField("Search...", text: $text)
                .padding(7)
                .background(Color(.systemGray6))
                .cornerRadius(8)
                .padding(.horizontal, 15)
            
            Button(action: {
                self.text = ""
            }) {
                Image(systemName: "xmark.circle.fill")
                    .foregroundColor(.gray)
            }
        }
    }
}
