//
//  BusinessCardView.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 16/02/23.
//

import Foundation
import SwiftUI

extension Color {
    init(hex: String) {
        let scanner = Scanner(string: hex)
        var rgbValue: UInt64 = 0
        scanner.scanHexInt64(&rgbValue)
        
        let red = Double((rgbValue & 0xFF0000) >> 16) / 255.0
        let green = Double((rgbValue & 0x00FF00) >> 8) / 255.0
        let blue = Double(rgbValue & 0x0000FF) / 255.0
        
        self.init(red: red, green: green, blue: blue)
    }
}
struct BusinessCardView: View {
    @State private var selectedColor: Color = Color(hex:"F0F8FF")
    @State private var showColorMenu:Bool=false
    let colorDictionary: [String: Color] = [
        
        "aliceblue": Color(hex: "F0F8FF"),
        "antiquewhite": Color(hex:"FAEBD7"),
        "cornsilk": Color(hex:"FFF8DC"),
    ]
    
    var body: some View {
        TabView{
            ZStack{
                //            Rectangle()
                //                .foregroundColor(Color(hue:0.129, saturation: 0.236, brightness: 0.979))
                //                .padding(-100)
                Color.yellow
                    .opacity(0.35)
                    .edgesIgnoringSafeArea(.all)
                VStack {
                    
                    HStack {
                        
                        VStack{
                            
                            Text("")
                                .font(.headline)
                                .foregroundColor(.black)
                            Text("name")
                                .font(.body)
                                .foregroundColor(.black)
                            Text("Numero di telefono")
                                .font(.body)
                                .foregroundColor(.black)
                            Text("email")
                                .font(.body)
                                .foregroundColor(.black)
                        }.padding(10)
                        
                    }.aspectRatio(contentMode: .fit)
                        .padding()
                        .background(selectedColor)
                        .cornerRadius(1)
                    
                    
                    //                    ScrollView(.horizontal){
                    
                    HStack{
                        //                        if showColorMenu {
                        ForEach(Array(colorDictionary.keys), id: \.self) { key in
                            Button(action: {
                                self.selectedColor = self.colorDictionary[key]!
                                self.showColorMenu = false
                            }) {
                                Text("")
                                    .font(.headline)
                                    .padding()
                                    .background(self.colorDictionary[key])
                                    .clipShape(Circle())
                                    .foregroundColor(.white)
                                    .cornerRadius(5)
                            }
                            //                            .buttonBorderShape(.capsule)
                            //                            .border(.black, width: 2)
                            .buttonStyle(.bordered)
                            .tint(.purple)
                            .padding(3)
                            
                            
                        }
                    }
                    //                    }
                    
                }
            }
            //        .padding(.leading)
        }
    }
    
}
//}
struct BusinessCardView_Previews: PreviewProvider {
    static var previews: some View {
        BusinessCardView()
    }
}
