import SwiftUI
import PhotosUI

struct DatiAzienda: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    @State private var isShown: Bool = false
    @State private var sourceType: UIImagePickerController.SourceType = .camera
    @State var nomeAzienda = ""
    @State var Ruolo = ""
    @Binding var isPresented: Bool
    @ObservedObject var viewModel: iPhoneViewModel
    @State var personalData = IstanzeBigliettoAziendale()
    @Binding var cards: [IstanzeBigliettoAziendale]
    
    var body: some View {
        NavigationView{
            ZStack{
                
                VStack{
                    Spacer()
                    Text("Inserisci i Dati della tua Azienda")
                        .font(.title)
                        .bold()
                        .padding(20)
                        .foregroundColor(.black)
                    
                    TextField("Nome Azienda", text: $personalData.azienda)
                        .padding().frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.1))
                        .cornerRadius(10)
                    TextField("Ruolo", text: $personalData.ruolo)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.1))
                    TextField("Nome", text: $personalData.nome)
                        .padding().frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.1))
                        .cornerRadius(10)
                    TextField("Cognome", text: $personalData.cognome)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.1))
                        .cornerRadius(10)
                    TextField("Numero", text: $personalData.numero)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.1))
                        .cornerRadius(10)
                    TextField("Email", text: $personalData.email)
                        .padding().frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.1))
                        .cornerRadius(10)
                    
                    
                    NavigationLink(destination:{
                        BigliettoAziendale(viewModel: viewModel, biglietto: personalData, isPresented: $isPresented, cards: $cards)
                        //                    cards.append(personalData)
                    }, label: {
                        Text("Avanti")
                        
                    })
                    
                }.position(x: 200,y:200)
                VStack{
                    if let data = data, let uiimage = UIImage(data: data) { Image(uiImage: uiimage)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 350)
                            .clipShape(Circle())
                            .position(x: 200, y: 550)
                        
                    }
                    Spacer()
                    PhotosPicker("photo", selection: $selectedItems, maxSelectionCount: 1, matching: .images
                    )
                    //                    .position(x:188,y:280)
                    .onChange(of: selectedItems) {
                        newValue in guard let item = selectedItems.first else {
                            return
                        }
                        item.loadTransferable(type: Data.self) { result in switch result {
                        case .success(let data): if let data = data {
                            self.data = data
                        } else{
                            print("Data is nil")
                        }
                        case.failure(let failure): fatalError("failure")
                        }
                        }
                        
                    }
                }
            }
        }
    }
}



struct BigliettoAziendale:View{
    
    @ObservedObject var viewModel: iPhoneViewModel
    var biglietto: IstanzeBigliettoAziendale
    @Binding var isPresented: Bool
    @Binding var cards: [IstanzeBigliettoAziendale]
    
    var body: some View{
        
        RoundedRectangle(cornerRadius: 25)
            .frame(width: 365, height: 250)
            .foregroundColor(Color.init(hex: "FFFFFF"))
            .border(.black)
            .cornerRadius(0)
            .overlay{
                
                VStack{
                    HStack{
                        Spacer()
                        Image("profilo")
                            .resizable()
                            .frame(width: 70, height: 55)
                            .clipShape(Circle())
                        
                        
                    }
                    HStack{
                        Spacer()
                        VStack{
                            Text(biglietto.nome + " " + biglietto.cognome)
                                .bold()
                        }
                    }
                    HStack{
                        Spacer()
                        VStack{
                            Text(biglietto.numero)
                        }
                    }
                    HStack{
                        VStack{
                            Text(biglietto.azienda)
                        }
                        Spacer()
                        VStack{
                            Text(biglietto.email)
                        }
                    }
                    HStack{
                        VStack{
                            Text(biglietto.ruolo)
                        }
                        Spacer()
                        VStack{
                            Text("Ulteriori contatti")
                        }
                    }
                    HStack{
                        VStack{
                            //                            Image("icon4")
                            Image("Biglietto")
                                .resizable()
                                .frame(width: 70, height: 55)
                                .clipShape(Rectangle())
                        }
                        Spacer()
                    }
                }.padding()
            }
            .navigationBarItems(trailing: Button(action: {
                cards.append(biglietto)
                isPresented = false
            }, label: {
                Text("Done")
            }))
        
        
        
    }
}

struct BigliettoAziendale3:View{
    @ObservedObject var viewModel: iPhoneViewModel
    var biglietto: IstanzeBigliettoAziendale
    @Binding var isPresented: Bool
    //    @Binding var selectedItems: [PhotosPickerItem]
    
    var body: some View{
        RoundedRectangle(cornerRadius: 25)
            .frame(width: 365, height: 250)
            .foregroundColor(Color.init(hex: "FFFFFF"))
            .border(.black)
            .cornerRadius(0)
            .overlay{
                
                VStack{
                    HStack{
                        Spacer()
                        Image("profilo")
                            .resizable()
                            .frame(width: 70, height: 55)
                            .clipShape(Circle())
                        
                        
                    }
                    HStack{
                        Spacer()
                        VStack{
                            Text(biglietto.nome + " " + biglietto.cognome)
                                .bold()
                        }
                    }
                    HStack{
                        Spacer()
                        VStack{
                            Text(biglietto.numero)
                        }
                    }
                    HStack{
                        VStack{
                            Text(biglietto.azienda)
                        }
                        Spacer()
                        VStack{
                            Text(biglietto.email)
                        }
                    }
                    HStack{
                        VStack{
                            Text(biglietto.ruolo)
                        }
                        Spacer()
                        VStack{
                            Text("Ulteriori contatti")
                        }
                    }
                    HStack{
                        VStack{
                            //                            Image("icon4")
                            Image("Biglietto")
                                .resizable()
                                .frame(width: 70, height: 55)
                                .clipShape(Rectangle())
                            
                        }
                        Spacer()
                        
                    }
                }.padding()
            }
    }
}

struct ImagePicker: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    var body: some View {
        VStack{
            if let data = data, let uiimage = UIImage(data: data) { Image(uiImage: uiimage)
                    .resizable()
            }
            Spacer()
            PhotosPicker("Your Photo", selection: $selectedItems, maxSelectionCount: 1, matching: .images
            )
            .onChange(of: selectedItems) {
                newValue in guard let item = selectedItems.first else {
                    return
                }
                item.loadTransferable(type: Data.self) { result in switch result {
                case .success(let data): if let data = data {
                    self.data = data
                } else{
                    print("Data is nil")
                }
                case.failure(let failure): fatalError("failure")
                }
                }
            }
        }
    }
}
