
import WatchConnectivity
import SwiftUI

class iPhoneViewModel: NSObject, ObservableObject, WCSessionDelegate {
  @Published var receivedMessage: Int = 0
    @Published var meetingCode: String = ""

  private let session = WCSession.default

  func sendMessageToWatch(_ message: Int) {
    session.sendMessage(["message": message], replyHandler: nil) { (error) in
      print(error.localizedDescription)
    }
  }

  override init() {
    super.init()

    if WCSession.isSupported() {
      session.delegate = self
      session.activate()
    }
  }

  func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
    // Implementazione obbligatoria
  }

  func sessionDidBecomeInactive(_ session: WCSession) {
    // Implementazione opzionale
  }

  func sessionDidDeactivate(_ session: WCSession) {
    // Implementazione opzionale
  }

  func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
    if let message = message["message"] as? String {
      meetingCode = message
    }
  }
}

//struct iPhoneContentView: View {
//  @ObservedObject var viewModel = iPhoneViewModel()
//  @State var count: Int = 1
//  var body: some View {
//    VStack {
//      Button(action: {
//        self.viewModel.sendMessageToWatch(self.count)
//      }) {
//        Text("Send message to watch: \(count)")
//      }
//    }
//  }
//}
//
//struct iPhoneContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        iPhoneContentView()
//    }
//}
