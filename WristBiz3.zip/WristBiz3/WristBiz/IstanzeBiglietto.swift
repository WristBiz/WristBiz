//
//  IstanzeBiglietto.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 14/02/23.
//

import SwiftUI
var i : Int=0

class IstanzeBigliettoAziendale: Hashable, Identifiable {
    
    var id = UUID()
    var azienda: String = " "
    var ruolo: String = " "
    var nome: String = " "
    var cognome: String = " "
    var numero: String = " "
    var email: String = " "
    var indice : Int = i+1
    var Accettato: Bool = false

    
    func hash(into hasher: inout Hasher) {
        hasher.combine(azienda)
        hasher.combine(ruolo)

    }
    init(azienda: String, ruolo: String, nome: String, cognome: String, numero: String, email: String) {
        self.azienda = azienda
        self.ruolo = ruolo
        self.nome = nome
        self.cognome = cognome
        self.numero = numero
        self.email = email
    }
     
    init() {}
    
    static func == (lhs: IstanzeBigliettoAziendale, rhs: IstanzeBigliettoAziendale) -> Bool {return true}
    
   
}
