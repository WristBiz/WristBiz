//
//  TabView.swift
//  carte
//
//  Created by Assunta Pia Clarino on 16/02/23.
//

import Foundation
import SwiftUI
import PhotosUI
struct MyTabView: View {
    @State var selectedItems: [PhotosPickerItem] = []
    @State var data: Data?
    @State var personalData = IstanzeBigliettoAziendale()
    @State private var selectedTab = 0
    @State var BigliettiSalvati : [IstanzeBigliettoAziendale] = [IstanzeBigliettoAziendale()]
    @StateObject var viewModel = iPhoneViewModel()
    
    var body: some View {
                    
                    TabView(selection: $selectedTab){
                    NavigationStack {
                                RicevutiSalvati(bigliettiSalvati: $BigliettiSalvati)
                    }
                    .tabItem {
                        Text("Salvati")
                        Image(systemName: "folder.badge.person.crop")
                        
                            .padding()
                    }
                    .foregroundColor(Color(red: 0.000, green: 0.013, blue: 0.422))
                    .tag(0)
                    
                    Color.white
                        .opacity(0.25)
                        .edgesIgnoringSafeArea(.all)
                        .overlay(
                            BigliettiRicevuti(personalData: personalData,BigliettiSalvati: $BigliettiSalvati,meetingCode: $viewModel.meetingCode)
//                            LeggiBiglietti(viewModel: viewModel, personalData: personalData)
                        )
                        .tabItem {
                            Text("Ricevuti")
                            Image(systemName: "tray.and.arrow.down")
                                .padding()
                        }
                        .tag(1)
                    
                    Color.white
                        .opacity(0.25)
                        .edgesIgnoringSafeArea(.all)
                        .overlay(
                            //                            Text("tab3")
                            Wallet(viewModel: viewModel, currentCard: IstanzeBigliettoAziendale())
                           
                            
                        )
                        .tabItem {
                            Text("Miei")
                            Image(systemName: "shared.with.you")
                                .padding()
                        }
                        .tag(2)
                        
                    Color.white
                        .opacity(0.25)
                        .edgesIgnoringSafeArea(.all)
                        .overlay(
                                //                            Text("tab3")
                            Riunioni(viewModel: viewModel)
                                
                            )
                            .tabItem {
                                Text("Riunioni")
                                Image(systemName: "list.number")
                                    .padding()
                            }
                            .tag(3)
                }
                .gesture(DragGesture()
                            .onEnded({ (value) in
                                if value.translation.width > 0 {
                                    selectedTab = max(selectedTab - 1, 0)
                                } else {
                                    selectedTab = min(selectedTab + 1, 2)
                                }
                            }))
                .accentColor(Color(red: 0.000, green: 0.013, blue: 0.422))
                .toolbar(.visible, for: .tabBar)
                .toolbarBackground(Color(red: 0.000, green: 0.013, blue: 0.422), for: .tabBar)
                .background(Color(red: 0.000, green: 0.013, blue: 0.422))
            }
        }
struct TabView_Previews: PreviewProvider {
    static var previews: some View {
        MyTabView()
    }
}

