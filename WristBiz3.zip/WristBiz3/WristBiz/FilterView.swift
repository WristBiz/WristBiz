
//  FilterView.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 17/02/23.


//import SwiftUI

//import SwiftUI
//
//struct FilterView: View {
//    @State private var isFilterVisible = false
//    @State private var selectedDate = Date()
//    
//    var body: some View {
//        VStack {
//            Button(action: {
//                isFilterVisible.toggle()
//            }) {
//                Image(systemName: "calendar.badge.clock" ).foregroundColor(.black)
//            }
//            .padding()
//            .sheet(isPresented: $isFilterVisible, content: {
//                VStack {
//                    DatePicker("Select date", selection: $selectedDate, displayedComponents: .date).foregroundColor(.black)
//                        .datePickerStyle(GraphicalDatePickerStyle())
//                        .padding(.vertical, 10)
//                    
//                    Button("Apply Filter") {
//                        // Add code here to apply the filter
//                        isFilterVisible.toggle()
//                    }
//                    .foregroundColor(.white)
//                    .padding()
//                    .background(Color.black)
//                    .cornerRadius(10)
//                    .padding(.top, 10)
//                }
//                .foregroundColor(.yellow)
//                .padding(.vertical, 10)
//                .padding(.horizontal, 20)
//                .background(Color.white.opacity(0.2))
//                .cornerRadius(10)
//            })
//        }
//    }
//}
//struct FilterView_Previews: PreviewProvider {
//    static var previews: some View {
//        FilterView()
//    }
//}
