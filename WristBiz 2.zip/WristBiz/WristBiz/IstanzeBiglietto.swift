//
//  IstanzeBiglietto.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 14/02/23.
//

import SwiftUI

struct IstanzeBiglietto: Hashable {
    var nome: String
    var cognome: String
    var numero: String
    var email: String
    var Accettato: Bool
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(nome)
        hasher.combine(cognome)
        hasher.combine(numero)
        hasher.combine(email)
    }
}
