//
//  BigliettiRicevuti.swift
//  WalletUI
//
//  Created by Ciro Pazzi on 07/02/23.
//

import SwiftUI

struct BigliettiRicevuti: View {
    public var ScartaBiglietti: [IstanzeBiglietto] = []
    public var personalData: IstanzeBiglietto
    
    init(personalData: IstanzeBiglietto) {
        self.personalData = personalData
    }
    
    var body: some View {
        ZStack{
            Rectangle()
                .foregroundColor(Color(hue: 0.129, saturation: 0.236, brightness: 0.979))
                .padding(-100)
            Text("Non hai più Nuovi Biglietti da Visita Ricevuti!")
                .font(.title)
                .bold()
                .padding(20)
                .foregroundColor(.black)
                
            VStack {
                ZStack {
                    ForEach(ScartaBiglietti, id: \.self) { person in
                        CardView(person: person)
                    }
                }
            }
        }
    }
}


struct CardView: View {
    @State var offset = CGSize.zero
    @State var color: Color = .yellow
     var person: IstanzeBiglietto
    
    var body: some View {
        ZStack {
            Rectangle()
                .frame(width: 420, height: 320)
                .border(.white, width: 6.0)
                .cornerRadius(4)
                .foregroundColor(color.opacity(0.9))
                .shadow(radius: 4)
            HStack {
                Image("Biglietto1")
                    .resizable()
                    .frame(width: 380, height: 200)
                    .aspectRatio(contentMode: .fit)
            }
            
        }
        .offset(x: offset.width * 1, y: offset.height * 0.4)
        .rotationEffect(.degrees(Double(offset.width / 40)))
        .gesture(
            DragGesture()
                .onChanged { gesture in
                    offset = gesture.translation
                    withAnimation {
                        changeColor(width: offset.width)
                    }
                }
                .onEnded { _ in
                    withAnimation {
                        swipeCard(width: offset.width)
                        changeColor(width: offset.width)
                    }
                }
        )
    }
    func swipeCard(width: CGFloat) {
        switch width {
        case -500...(-150):
            print("\(person) removed")
            offset = CGSize(width: -500, height: 0)
            person.Accettato = false
        case 150...500:
            print("\(person) added")
            offset = CGSize(width: 500, height: 0)
            person.Accettato = true
        default:
            offset = .zero
        }
    }
    
    func changeColor(width: CGFloat) {
        switch width {
        case -500...(-130):
            color = .red
        case 130...500:
            color = .green
        default:
            color = .yellow
        }
    }
    
    
}

//struct CardView_Previews: PreviewProvider {
//    static var previews: some View {
//        CardView(person: "Mario")
//    }
//}

//struct BigliettiRicevuti_Previews: PreviewProvider {
//    static var previews: some View {
//        BigliettiRicevuti(personalData: personalData)
//    }
//}


