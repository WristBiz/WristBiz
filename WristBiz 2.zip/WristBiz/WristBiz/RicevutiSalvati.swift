//
//  RicevutiSalvati.swift
//  WristBiz
//
//  Created by Ciro Pazzi on 15/02/23.
//

import SwiftUI

struct RicevutiSalvati: View {
    var body: some View {
        ZStack{
            
            Rectangle()
                .foregroundColor(Color(hue: 0.129, saturation: 0.236, brightness: 0.979))
                .padding(-100)
            Text("Ricevuti")
                .padding()
                .fontWeight(.bold)
                .foregroundColor(.black)
                .font(.title)
                .position(x: 90, y: 30)
            
        }
    }
}

struct RicevutiSalvati_Previews: PreviewProvider {
    static var previews: some View {
        RicevutiSalvati()
    }
}
