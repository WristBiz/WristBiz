//
//  ContentView.swift
//  conn4 Watch App
//
//  Created by Ciro Pazzi on 11/02/23.
//

import WatchConnectivity
import SwiftUI

class WatchViewModel: NSObject, ObservableObject, WCSessionDelegate {
  @Published var receivedMessage: Int = 0
   
  private let session = WCSession.default

  func sendMessageToiPhone(_ message: String) {
    session.sendMessage(["message": message], replyHandler: nil) { (error) in
      print(error.localizedDescription)
    }
  }

  override init() {
    super.init()

    if WCSession.isSupported() {
      session.delegate = self
      session.activate()
    }
  }

  func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
    // Implement this method to handle the activation state of a session.
  }

  func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
    if let message = message["message"] as? Int {
      receivedMessage = message
    }
  }
}

struct WatchContentView: View {
  @ObservedObject var viewModel = WatchViewModel()
@State var Count: Int = 1
    var body: some View {
        NavigationView{
            ScrollView{
                VStack {
                    Text("\(viewModel.receivedMessage)").onReceive(viewModel.$receivedMessage) { (message) in
                        self.Count = message
                        //      Button(action: {
                        //        self.viewModel.sendMessageToiPhone("\(Count)")
                        //      }) {
                        //        Text("Send message to iPhone")
                        //      }
                    }
                    //              Count=viewModel.receivedMessage
                    ZStack{
                        VStack{
                            switch(Count){
                            case(0):
                                NavigationLink(destination: SceltaInviati()) {
                                    Image("Biglietto1")
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .font(.title)
                                        .foregroundColor(.white)
                                    
                                }
                                .tint(.black)
                            case(1):
                                NavigationLink(destination: SceltaInviati()) {
                                    Image("Biglietto2")
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .font(.title)
                                        .foregroundColor(.white)
                                    
                                }
                                .tint(.black)
                            case(2):
                                NavigationLink(destination: SceltaInviati()) {
                                    Image("Biglietto3")
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .font(.title)
                                        .foregroundColor(.white)
                                    
                                }
                                .tint(.black)
                            default:
                                Text("Error")
                            }
                        }
                    }
                }
            }
        }
    }
}
struct WatchContentView_Previews: PreviewProvider {
    static var previews: some View {
        WatchContentView()
    }
}
