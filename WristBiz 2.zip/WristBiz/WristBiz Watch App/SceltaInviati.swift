//
//  SceltaInviati.swift
//  WristBiz Watch App
//
//  Created by Ciro Pazzi on 10/02/23.
//

import SwiftUI

struct SceltaInviati: View {
    @State private var number = ""

    var body: some View {
        ScrollView{
            VStack(spacing: 1) {
                Text("\(number)")
                    .font(.largeTitle)
                    .bold()
                    .padding()
                HStack(spacing: 1) {
                    ForEach(1...3, id: \.self) { row in
                        VStack(spacing: 1) {
                            ForEach(1...3, id: \.self) { column in
                                Button("\((row - 1) * 3 + column)") {
                                    self.number.append("\((row - 1) * 3 + column)")
                                }
                            }
                        }
                    }
                }
                
                
            HStack {
                Button("Clear") {
                    self.number = ""
                }.tint(Color(hue: 0.109, saturation: 0.602, brightness: 0.982))
                    .padding(.horizontal, 30)
                    .background(Color(hue: 0.109, saturation: 0.602, brightness: 0.982))
                    .cornerRadius(20)
                Spacer()
            }
            }.padding(20)
        }
    }
}
struct SceltaInviati_Previews: PreviewProvider {
    static var previews: some View {
        SceltaInviati()
    }
}
